package data;

public class Credenciales {

	private String usuario;
	private String usuarioAdicional;
	private String clave;
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getUsuarioAdicional() {
		return usuarioAdicional;
	}
	public void setUsuarioAdicional(String usuarioAdicional) {
		this.usuarioAdicional = usuarioAdicional;
	}
	public String getClave() {
		return clave;
	}
	public void setClave(String clave) {
		this.clave = clave;
	}	
}

