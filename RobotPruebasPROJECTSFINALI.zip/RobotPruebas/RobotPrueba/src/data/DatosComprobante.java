package data;

public class DatosComprobante {
	
	
	private String tipoComprobante;
	private String fechaAutorizacion;
	private String rucReceptor;
	private String correoReceptor;
	private String cantidadPendiente;
	
	public String getCantidadPendiente() {
		return cantidadPendiente;
	}
	public void setCantidadPendiente(String cantidadPendiente) {
		this.cantidadPendiente = cantidadPendiente;
	}

	public String getTipoComprobante() {
		return tipoComprobante;
	}
	public void setTipoComprobante(String tipoComprobante) {
		this.tipoComprobante = tipoComprobante;
	}
	public String getFechaAutorizacion() {
		return fechaAutorizacion;
	}
	public void setFechaAutorizacion(String fechaAutorizacion) {
		this.fechaAutorizacion = fechaAutorizacion;
	}
	public String getRucReceptor() {
		return rucReceptor;
	}
	public void setRucReceptor(String rucReceptor) {
		this.rucReceptor = rucReceptor;
	}
	public String getCorreoReceptor() {
		return correoReceptor;
	}
	public void setCorreoReceptor(String correoReceptor) {
		this.correoReceptor = correoReceptor;
	}
	
	 

}
