package com.corlasosa.pruebas;

import org.sikuli.script.Screen;

public class VerificacionFallidos {
	
	private int lValidaPantalla=0;
	
	//comstructor
	
	public VerificacionFallidos(int lValidaPantalla) {
		super();
		this.lValidaPantalla = lValidaPantalla;
	}
	
	public int getlValidaPantalla() {
		return lValidaPantalla;
	}

	public void setlValidaPantalla(int lValidaPantalla) {
		this.lValidaPantalla = lValidaPantalla;
	}


	
	public int validScreen(Screen s) {
		
	
		
		
		return 0 ;
	}
	
	
	
	


}
