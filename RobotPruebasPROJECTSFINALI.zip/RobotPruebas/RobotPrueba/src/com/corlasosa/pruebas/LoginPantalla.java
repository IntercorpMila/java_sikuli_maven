package com.corlasosa.pruebas;

import org.apache.log4j.Logger;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Key;
import org.sikuli.script.Match;
import org.sikuli.script.Screen;

import util.ServicioPropertie;

public class LoginPantalla {

	private static Logger lLogger = Logger.getLogger(LoginPantalla.class);
	
	public LoginPantalla clickLogIn(Screen s,String pAccion,int pTime)  {
		try {
			s.click("/"+pAccion,pTime);
		} catch (FindFailed e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			lLogger.error(e);
		}
		return this;
	}
	
	public void PosicionPantalla(Screen pScreen, int pCantidadClick, boolean pBoton)  {

		for(int i=0; i<=pCantidadClick;i++) {
	
			if(pBoton)
			pScreen.type(Key.DOWN);
			else
			pScreen.type(Key.RIGHT);
			
		}
	}
	
	 public static Match TiempoEspera(Screen pScreen, String pNomFor,
				int pNumFor,int pNumThread) {

			Match lMatchFound = pScreen.exists("/" + pNomFor);
			for (int i = 0; i < pNumFor; i++) {
				lMatchFound = pScreen.exists("/" + pNomFor);
				if (lMatchFound == null) {
					try {
						Thread.sleep(pNumThread);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						lLogger.error(e);
					}
				} else {
					break;
				}
			}
			return  lMatchFound ;
		}
	 
	 public void CerrarSesion(Screen pScreen,String pCerrarSesion) {

			try {
				pScreen.click(pScreen.exists("/"+pCerrarSesion),
				Integer.parseInt(ServicioPropertie.getPropiedad("tiempoDespPantalla")));
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				lLogger.error(e);
			} catch (FindFailed e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				lLogger.error(e);
			}
				
		}
	 
	 public static void OmisionClave(Screen pScreen,
			int pCantFor, int pCantThread) {

		for (int i = 0; i < pCantFor; i++) {
			
			try {
				Thread.sleep(pCantThread);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				lLogger.error(e);
			}
			pScreen.type(Key.TAB);
		}
		try {
			Thread.sleep(pCantThread);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			lLogger.error(e);
		}
		pScreen.type(Key.TAB + Key.ENTER);
	}
}
