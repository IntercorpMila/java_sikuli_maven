package com.corlasosa.pruebas;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map.Entry;
import java.util.TreeMap;
import org.apache.log4j.Logger;
import org.sikuli.script.App;
import org.sikuli.script.FindFailed;
import org.sikuli.script.ImagePath;
import org.sikuli.script.Key;
import org.sikuli.script.Match;
import org.sikuli.script.Screen;
import accesoBD.GestionDB;
import data.Credenciales;
import util.ExcepcionEncriptacion;
import util.ServicioPropertie;
import util.UtilCryptography;
import com.tigervnc.rdr.Exception;
import comprobanteselectronicos.conector.servicioweb.DatosCompania;
import comprobanteselectronicos.conector.servicioweb.ServicioConsultaEmpresasService;
import comprobanteselectronicos.conector.servicioweb.ServicioConsultaEmpresas;


public class RobotPruebas {
	  
	RobotPruebas disparadorClase=new RobotPruebas();
	
	private static Logger lLogger = Logger.getLogger(RobotPruebas.class);
	
	
	/**
	 * @param args
	 * @throws java.lang.Exception 
	 * @throws Exception
	 * @throws ExcepcionEncriptacion
	 * @throws FindFailed
	 * @throws InterruptedException
	 */
	
	public static String lDirProperties=null;
	
	
	public static void main(String[] args) throws java.lang.Exception {
	
		System.out.println("-------------------Ingreso al main------------------");
		lLogger.info("-------------------Ingreso al main------------------");
		
		 	System.out.println("-------------------KILL CHROME------------------");
			lLogger.info("-------------------KILL CHROME------------------");
			Runtime rt = Runtime.getRuntime();
			Process pr = rt.exec("taskkill /F /IM chrome.exe /T");
			System.out.println("-------------------KILL CHROME------------------");
			lLogger.info("-------------------KILL CHROME------------------");
		
		try {
		System.out.println("******** INI SETEO DE VARIABLES DEL PROGRAMA*********************");
		lLogger.info("******** INI SETEO DE VARIABLES DEL PROGRAMA*********************");
		
		RobotSecurityCatchap robotCatchap =new RobotSecurityCatchap();
		LoginPantalla login =new LoginPantalla();
	    Screen s = new Screen();
		GestionDB lGestionDB = new GestionDB();
		Credenciales credenciales = new Credenciales();
		//ServicioPropertie  lServices =new ServicioPropertie();
		//Clipboard clpbrd=Toolkit.getDefaultToolkit().getSystemClipboard();;
		 
		int cSesion=0;
		int conDia=0;
		
		String driveChrome=null;
	    String mesDescarga=null;
	    String tipoComprobante=null;
	    String opcionAnio=null;
	    String diaDescarga=null;
	    String rucPrincipal=null;
	    String passDescrip = null;
	    String lUsuarioP;
	    String lUsuarioAdi;
	    String lPassword;
	    
	    //String lDirProperties=null;
	    
	    int lContador=0;
	
	    TreeMap<String, Integer> lListado = ExtraerMesesEjecucion.extraeMesesAProcesar();
	    
	    String tipoDescarga 	= args[0];
	    		lDirProperties  = args[1];
	    		diaDescarga 	= args[2];
	    		
	    System.out.println("***tipoDescarga::[0]*****"+tipoDescarga);
	    System.out.println("***lDirProperties [1]*****"+args[1].toString());
	    System.out.println("***diaDescarga::[2]*****"+diaDescarga);
	    System.out.println("******************************************************");
	    System.out.println(args[1].toString());
	    System.out.println(lDirProperties);
	    
	   
	    driveChrome= ServicioPropertie.getPropiedad("rutaChrome");
	    
	 // valida tecla mayuscula, y la desactiva, por problemas en el login si esta
	 // activa
	 boolean isOn = Toolkit.getDefaultToolkit().getLockingKeyState(KeyEvent.VK_CAPS_LOCK);
	 if (isOn == true) {
	 	 s.type(Key.CAPS_LOCK);
	 }
	    
	    if("0".equals(tipoDescarga) && ("".equals(diaDescarga)||"TODOS".equals(diaDescarga))) {
	    	
	    	opcionAnio=Integer.toString(Calendar.YEAR);
	 		mesDescarga= Integer.toString(Calendar.MONTH);
	 		//diaDescarga="";
	 		tipoComprobante="";
	 		//tipoComprobante=args[1];
	    }else if ("1".equals(tipoDescarga)) {
	    	
	    	//rucPrincipal = args[1];
	    	opcionAnio=args[1];
	 		mesDescarga= args[2];
	 		
	    	if(args.length<4) {
	    		diaDescarga="";
		 		tipoComprobante="";
	    	}else{
	    		diaDescarga=args[3];
		 		tipoComprobante=args[4];
	    	}
	    }
	    
		
	    System.out.println("******** FIN SETEO DE VARIABLES DEL PROGRAMA*********************");
		lLogger.info("******** FIN SETEO DE VARIABLES DEL PROGRAMA*********************");

			System.out.println("******** INI INGRESA A LOGEARSE Y CONSULTAR*********************");
			lLogger.info("******** INI INGRESA A LOGEARSE Y CONSULTAR*********************");

			//##PRODUCCION
			//ImagePath.setBundlePath("C:\\opt\\facturacion_electronica\\robotDescarga\\imagen");
			//##DESARROLLO
			ImagePath.setBundlePath("D:\\robotDescarga\\SeedBilling\\RobotDescarga\\imagen");
			
			System.out.println(ServicioPropertie.getPropiedad("rutaImagenes"));
			lLogger.info(ServicioPropertie.getPropiedad("rutaImagenes"));
			
			ServicioConsultaEmpresasService lServicioConsultaEmpresasService = new ServicioConsultaEmpresasService();
			ServicioConsultaEmpresas lServicioConsultaEmpresas = lServicioConsultaEmpresasService
					.getServicioConsultaEmpresasPort();
			
			//condicion para scar por suscriptor 
			GestionDB gestionDB = new GestionDB();
			
			
			List <String> lListaSuscriptores =new ArrayList<>();
			
			System.out.println("Antes de Obtener Lista de suscriptores");
			lLogger.info("Antes de Obtener Lista de suscriptores");
			lListaSuscriptores= gestionDB.obtenerSuscriptor();
			System.out.println("Despues de Obtener Lista de suscriptores:"+lListaSuscriptores);
			lLogger.info("Despues de Obtener Lista de suscriptores:"+lListaSuscriptores);
			
			System.out.println(lListaSuscriptores);
			lLogger.info(lListaSuscriptores);
			
			//COMENTADO POR PRUEBAS LGU
			//boolean lLimpieza=true;
			
			for (String lSuscriptor : lListaSuscriptores) {
				
				System.out.println("**VARIABLE INCIALIZADA**");
				lContador=1;
				System.out.println("**VARIABLE INCIALIZADA::**"+lContador);
				
				
				System.out.println("inicios de sesion::"+cSesion);
				
				System.out.println("lSuscriptor "+lSuscriptor);
				lLogger.info("lSuscriptor "+lSuscriptor);
				
				List <String> lListaCompanias =new ArrayList<>();
				System.out.println("Antes de Obtener Companias "+lSuscriptor);
				lLogger.info("Antes de Obtener Companias "+lSuscriptor);
				lListaCompanias= gestionDB.obtenerCompaniaSuscriptor(lSuscriptor);
				
				System.out.println("Despues de Obtener Companias "+lListaCompanias);
				lLogger.info("Despues de Obtener Companias "+lListaCompanias);
				
				for (String lCompania : lListaCompanias) {
				try {
					  
					
					System.out.println("Procesando la compania:"+lCompania);
					lLogger.info("Procesando la compania:"+lCompania);
					
					DatosCompania lDatosCompania = lServicioConsultaEmpresas.informacionCompania(lCompania,
							ServicioPropertie.getPropiedad("tokenRobot"));
					
					System.out.println("adicional::::"+lDatosCompania.getUsuarioAdicional());
					System.out.println("clave::::"+lDatosCompania.getClaveSRI());
					
					lDatosCompania.setUsuarioAdicional(
					lDatosCompania.getUsuarioAdicional() != null ? lDatosCompania.getUsuarioAdicional() : "");
					passDescrip = UtilCryptography.desencriptar(lDatosCompania.getClaveSRI());
				
					System.out.println("******** INI INICIALIZA NAVEGACION  *********************");
					lLogger.info("******** INI INICIALIZA NAVEGACION *********************");
					

					System.out.println("*****************************************");
					System.out.println("***********ENTRA POR 1ERA VEZ************");
					System.out.println("*****************************************");
					lContador=lContador-1;
					
					System.out.println("**INI lContador**::"+lContador);
					if (lContador==0) {
					Thread.sleep(4000);
					App.open(driveChrome);
					Thread.sleep(4000);
					System.out.println("RUTA CHROME 1ERA VEZ::"+driveChrome);
					s.type("w",Key.CTRL);
					}
					
					Thread.sleep(4000);
					App.open(driveChrome);
					Thread.sleep(4000);
					//if (s.exists("/loginGoogle.png")!=null) {
						s.paste("https://srienlinea.sri.gob.ec/tuportal-internet/");
						s.type(Key.ENTER);
					//}
					//if(lLimpieza) {
					//	System.out.println("**********ENTRA POR 2DA VEZ************");
					//	System.out.println("*****************************************");
					//	Thread.sleep(2000);
					//	App.open(driveChrome);
					//	Thread.sleep(1000);
					//	if (s.exists("/loginGoogle.png",10)!=null) {
					//	s.paste("https://srienlinea.sri.gob.ec/tuportal-internet/");
					//	s.type(Key.ENTER);
					//	}
					//	lLimpieza=false;
					//}
					Thread.sleep(100);

					Match lPagePrincipal= LoginPantalla.TiempoEspera(s, "ruc-ci.png", 1, 10000);
					if (lPagePrincipal != null) {
						if (lPagePrincipal.isValid()) {
					   
						System.out.println("*************  RUC - CI *************");
						
						s.wait("/ruc-ci.png", 200);
						s.type(Key.TAB);
						lUsuarioP=null;
						lUsuarioP =lCompania.trim();
						System.err.println("Usuario principal::"+lCompania.trim());
						//clpbrd.setContents(stringSelection, null);
						s.paste(lUsuarioP);
						s.type(Key.TAB);
					
						if( lDatosCompania.getUsuarioAdicional()!= null && !"".equals(lDatosCompania.getUsuarioAdicional().trim()) ) {
							lUsuarioAdi = lDatosCompania.getUsuarioAdicional();
							//clpbrd.setContents(stringSelection, null);
							s.paste(lUsuarioAdi);
							//s.type("v", Key.CTRL);
						}
						s.type(Key.TAB);
						
						lPassword=null;
						
						lPassword = passDescrip.trim();
						//clpbrd.setContents(stringSelection, null);
						s.paste(lPassword);
						//s.type("v", Key.CTRL);
						s.type(Key.TAB + Key.ENTER);
						s.type(Key.TAB + Key.ENTER);

						
						Thread.sleep(2000);
						
						/*Match lPagePrincipal= LoginPantalla.TiempoEspera(s, "ruc-ci.png", 1, 10000);
						if (lPagePrincipal != null) {
							if (lPagePrincipal.isValid()) {  */
						//if (s.exists("/imgNuevaDeclaracion.png")!=null) {
						
						
						
						if (s.exists("/imgNuevaDeclaracion.png")!=null) {
							System.out.println("****ENTRAAAAAAAAAAAAAAAA***");
							
							s.wait("/imgNuevaDeclaracion.png", Integer.parseInt(ServicioPropertie.getPropiedad("tiempoEsperaPantalla")));
							s.type(Key.TAB + Key.ENTER);
							
							 if(s.exists("/pantallaDeudaSegundo.png",10) != null){
								   System.out.println("ingresa a 2da pantalla ********");
									s.type(Key.TAB);
									s.type(Key.TAB);
									s.type(Key.TAB + Key.ENTER);
							 }
						} else if (s.exists("/recuperaClave2.png")!=null) {
							
							System.out.println("***RECUPERA CLAVE***");
							s.wait("/recuperaClave2.png", Integer.parseInt(ServicioPropertie.getPropiedad("tiempoEsperaPantalla")));
							
							s.click("/imgClickSalir.png",10000);
							
							
							if (s.exists("/imgNuevaDeclaracion.png")!=null) {
								
								s.wait("/imgNuevaDeclaracion.png", Integer.parseInt(ServicioPropertie.getPropiedad("tiempoEsperaPantalla")));
								s.type(Key.TAB + Key.ENTER);
								
								if(s.exists("/pantallaDeudaSegundo.png",0) != null){
									s.type(Key.TAB);
									s.type(Key.TAB);
									//s.type(Key.TAB);
									//s.type(Key.TAB);
									s.type(Key.TAB + Key.ENTER);
									
								}
							}
							
						}
						
						else if (s.exists("/tieneDeudas.png") != null) {
							
							Thread.sleep(2000);
					    	s.type(Key.TAB + Key.ENTER);

							if (s.exists("/otrasDeudas.png",0) != null) {
								
									s.type(Key.TAB);
									s.type(Key.TAB);
									s.type(Key.TAB + Key.ENTER);
									
							}
									
					    }				
						else if (s.exists("/recuperaClave.png")!=null) {
							
									login.clickLogIn(s, "recuperaClave.png", 10000);
									
									Thread.sleep(1500);
									LoginPantalla.OmisionClave(s,13,100);
									Thread.sleep(1000);
									
									if (s.exists("/tieneDeudas.png")!=null) {
										
										s.wait("/tieneDeudas.png", Integer.parseInt(ServicioPropertie.getPropiedad("tiempoEsperaPantalla")));
										s.type(Key.TAB + Key.ENTER);
										
										if (s.exists("/otrasDeudas.png",10)!=null) {
											s.type(Key.TAB);
											s.type(Key.TAB);
											s.type(Key.TAB + Key.ENTER);
										}
									}else if (s.exists("/imgNuevaDeclaracion.png")!=null) {
										
										s.wait("/imgNuevaDeclaracion.png", Integer.parseInt(ServicioPropertie.getPropiedad("tiempoEsperaPantalla")));
										s.type(Key.TAB + Key.ENTER);
										
										if(s.exists("/pantallaDeudaSegundo.png",0) != null){
											s.type(Key.TAB);
											s.type(Key.TAB);
											//s.type(Key.TAB);
											//s.type(Key.TAB);
											s.type(Key.TAB + Key.ENTER);
											
										}
									}
									
							}else if (s.exists("/imgActualizacionClave.png")!=null) {
								
								s.wait("/imgClickCasa.png", 30);
								Thread.sleep(2000);
								s.click(s.exists("/imgClickCasa.png"), 400);
								
							}
						else if (s.exists("/LoginInvalido.png")!=null){
								
									/*	Thread.sleep(10);
										
										if (s.exists("/cerrarNavegador") != null) {
											login.CerrarSesion(s, "cerrarNavegador");
										} else if (s.exists("/btnNavegadorRojo") != null) {
											login.CerrarSesion(s, "btnNavegadorRojo");
										} */
							            s.type("w",Key.CTRL);
										break;
									
							}else if (s.exists("/imgSriOffLine.png")!=null) {
								Thread.sleep(10);
								
							/*	if (s.exists("/cerrarNavegador", 0) != null) {
									login.CerrarSesion(s, "cerrarNavegador");
								} else if (s.exists("/btnNavegadorRojo", 10) != null) {
									login.CerrarSesion(s, "btnNavegadorRojo");
								} */
								s.type("w",Key.CTRL);
								break;
							}

						    Thread.sleep(200);
						    
							System.out.println("******** FIN INGRESA A LOGEARSE Y CONSULTAR*********************");
							lLogger.info("******** FIN INGRESA A LOGEARSE Y CONSULTAR*********************");
					    
							Match lModFactura = LoginPantalla.TiempoEspera(s, "facturaElectronica.png", 3, 30000);
							if (lModFactura != null) {
								if (lModFactura.isValid()) {
									
									login.clickLogIn(s, "facturaElectronica.png", 10000);
									Thread.sleep(200);
									
									Match lModElec= LoginPantalla.TiempoEspera(s, "imgComprobante.png", 3, 10000);
									if (lModElec != null) {
										if (lModElec.isValid()) {
											s.click(s.exists("/imgComprobante.png"), 10000);
											Thread.sleep(200);
											
											Match lpantallaComp= LoginPantalla.TiempoEspera(s, "imgPrincipalComprobante.png", 3, 20000);
											
											System.out.println("******** INI CARGA PARAMETROS EN PANTALLA DE DESCARGA*********************");
											lLogger.info("******* INI CARGA PARAMETROS EN PANTALLA DE DESCARGA*****************");
											if (lpantallaComp != null) {
												if (lpantallaComp.isValid()) {
												
													System.out.println("******** INI SELECCION DE DATOS FORMULARIO*********************");
													System.out.println("******** INI SELECCION DE DATOS FORMULARIO*********************");
													
													login.clickLogIn(s, "imgPrincipalComprobante.png", 10000);
													
													Thread.sleep(1000);
													
											if("0".equals(tipoDescarga)) {
												
											System.out.println("******** INI RECORRIDO DE A�O - MES POR DEFAULT*********************");
											lLogger.info("******* INI RECORRIDO DE A�O - MES POR DEFAULT*****************");
											for(Entry<String, Integer> entry : lListado.entrySet()) {	
												
												
													//CONDICION DE DIA TODOS
													if (diaDescarga.isEmpty()) 
													{
														
														login.clickLogIn(s, "imgClickValidacion.png", 10000);
													    Thread.sleep(100);
														RobotAsignaFecha.AsignaAnio(s, Integer.toString(entry.getValue()));  //opcionAnios
													
														//Hasta aqui lleg�
														login.clickLogIn(s, "imgClickValidacion.png", 10000);
														Thread.sleep(100);
														RobotAsignaFecha.AsignaMes(s,entry.getKey()); //mesDescarga
														
														System.out.println("******** INI SELECCION TODOS*********************");
														lLogger.info("******** INI SELECCION TODOS*********************");
														
														RobotAsignaFecha.AsignaDia(s,diaDescarga);
														
														//Tipo de comprobante
														s.type(Key.TAB);
														for(int c2=1;c2<=4;c2++) {
															s.type(Key.UP);
													    }
														System.out.println("******** INI TIPO DE COMPROBANTE*********************");
														lLogger.info("******** INI TIPO DE COMPROBANTE*********************");
														
														RobotAsignaFecha.AsignaTipoComprobante(s,tipoComprobante);
														
														
														System.out.println("******** INI TIPO DE COMPROBANTE*********************");
														lLogger.info("******** INI TIPO DE COMPROBANTE*********************");
														
														Thread.sleep(30);
														if (s.exists("/pZoom", 0) != null) {
															ValidaPantalla.ZoomPagina(s, "pZoom", true, 6);
															s.click(s.exists("/pZoom.png"), 1000);
														} else {
															ValidaPantalla.ZoomPagina(s, "btnActualizar.png", true, 6);
															s.click(s.exists("/btnDespues.png"), 1000);
														}
														
												Thread.sleep(30);
												
												Match lvalidaPantalla= LoginPantalla.TiempoEspera(s, "conPantalla", 3, 2000);
												if (lvalidaPantalla != null) {
													if (lvalidaPantalla.isValid()) {
														
														if (conDia==0) {
															s.click(s.exists("/conPantalla.png"), 2000);
															login.PosicionPantalla(s, 32, true);
															login.PosicionPantalla(s, 8, false);
															
														}else if (s.exists("/conPantalla.png")!=null) {
																s.click(s.exists("/conPantalla.png"), 2000);
																login.PosicionPantalla(s, 27, true);
																login.PosicionPantalla(s, 8, false);
														}
														else if(s.exists("/imgSinComprobante.png",10)!=null) 
														{
													        s.click(s.exists("/imgSinComprobante.png"), 10000);
															login.PosicionPantalla(s, 35, true);
															login.PosicionPantalla(s, 8, false);
														}	
														
														
													Thread.sleep(30); 
													
													System.out.println("******** INI ASIGNACION CAPCHA*********************");
													lLogger.info("******** INI ASIGNACION CAPCHA *********************");
													
													robotCatchap.asignaCapcha(s);
													
													System.out.println("******** FIN ASIGNACION CAPCHA*********************");
													lLogger.info("******** FIN ASIGNACION CAPCHA *********************");
													
													Thread.sleep(10); 
													
													//Pattern lPCompTer = new Pattern("/CompTercero");
													//Pattern lSPComp = lPCompTer.exact();
													
													//if (s.exists(lSPComp) != null) {
														
														Match lvalidaConsulta= LoginPantalla.TiempoEspera(s,"CompTercero", 3, 120000);
														if (lvalidaConsulta!=null) {
															if (lvalidaConsulta.isValid()) {
																

																//System.out.println("Por aqui");
																Thread.sleep(10);
																//if (s.exists("/CompTercero")!=null) {
																//s.click(s.exists("/CompTercero"), 1000);
																login.PosicionPantalla(s, 35, true);
																//login.PosicionPantalla(s, 44, true);
																//}
																//else if(s.exists("/imgSinComprobante")!=null) {
																//s.click(s.exists("/imgSinComprobante"), 1000);
																//login.PosicionPantalla(s, 53, true);		
															    //}
															
																System.out.println("******** INI BOTON DE EJECUCION DE DESCARGAR  *********************");
																lLogger.info("******** INI BOTON DE EJECUCION DE DESCARGAR *********************");
																
																Match lbtnDescarga = LoginPantalla.TiempoEspera(s,"btnDescargaRep", 3, 10000);
																
																if (lbtnDescarga != null) {
																	if (lbtnDescarga.isValid()) {
																		Thread.sleep(30); 
																		
																		s.click(s.exists("/btnDescargaRep.png"), 10000);
																		
																		System.out.println("******** FIN BOTON DE EJECUCION DE DESCARGAR  *********************");
																		lLogger.info("******** FIN BOTON DE EJECUCION DE DESCARGAR *********************");
																		
																		try {
																			System.out.println("******** INI INSERCION DE INFORMACION POR EXITO *********************");
																			lLogger.info("******** INI INSERCION DE INFORMACION POR EXITO *********************");
																			
																			lGestionDB.insertarLog(rucPrincipal, "EXITO: La Descarga del Anio"+entry.getValue()+" ,Mes:"+entry.getKey()+
																					              " ,Dia: TODOS TIPO COMPROBANTE: TODOS"
																								,  "1"); /// 1 Exito
																			
																			System.out.println("******** FIN INSERCION DE INFORMACION POR EXITO *********************");
																			lLogger.info("******** FIN INSERCION DE INFORMACION POR EXITO *********************");
																			
																		} catch (java.lang.Exception exception) {
																			// TODO Auto-generated catch block
																			lLogger.error(exception);
																			exception.printStackTrace();
																		}
																		
																if (s.exists("/pZoom", 0) != null) {
																	s.click(s.exists("/pZoom.png"), 1000);
																	ValidaPantalla.ZoomPagina(s, "pZoom", false, 6);
																	s.click(s.exists("/pZoom.png"), 2000);
																	
																} else {
																	s.click(s.exists("/btnActualizar.png"), 1000);
																	ValidaPantalla.ZoomPagina(s, "btnActualizar", false, 6);
																	s.click(s.exists("/btnActualizar.png"), 2000);
																}
																//Thread.sleep(500);
																
															/*	for (int n = 0; n <= 25; n++) {
																	s.type(Key.UP);
																}*/
																
															}}else {
																
																System.out.println("******** INI NO SE ENCUENTRA BOTON DESCARGA*********************");
																lLogger.info("******** INI NO SE ENCUENTRA BOTON DESCARGA*********************");
																try {
																	lGestionDB.insertarLog(rucPrincipal, "ERROR: No termin� con exito la descarga del Anio"+entry.getValue()+" ,Mes:"+entry.getKey()+
																			 " ,Dia: TODOS TIPO COMPROBANTE: TODOS", "-1"); /// -1 Error
																} catch (java.lang.Exception exception) {
																	// TODO Auto-generated catch block
																	lLogger.error(exception);
																	exception.printStackTrace();
																}
																System.out.println("******** FIN NO SE ENCUENTRA BOTON DESCARGA*********************");
																lLogger.info("******** FIN NO SE ENCUENTRA BOTON DESCARGA*********************");
																
																Thread.sleep(1000);
																if (s.exists("/cerrarNavegador.png", 0) != null) {
																	login.CerrarSesion(s, "cerrarNavegador.png");
																} else if (s.exists("/btnNavegadorRojo.png", 10) != null) {
																	login.CerrarSesion(s, "btnNavegadorRojo.png");
																}
																
																System.out.println("******** FIN NO SE ENCUENTRA BOTON DESCARGA*********************");
																lLogger.info("******** FIN NO SE ENCUENTRA BOTON DESCARGA*********************");
															}
																Thread.sleep(1000);
																for (int n = 0; n <= 25; n++) {
																	s.type(Key.UP);
																}
															
																
															}
															}else {
																/*System.out.println("Cerrando el Modulo Comprobantes electronicos");
																Thread.sleep(10);

																if (s.exists("/cerrarNavegador", 0) != null) {
																	login.CerrarSesion(s, "cerrarNavegador");
																} else if (s.exists("/btnNavegadorRojo", 10) != null) {
																	login.CerrarSesion(s, "btnNavegadorRojo");
																}*/
																//validacion de imagenes
																Match	lvalidacomprob= LoginPantalla.TiempoEspera(s,"imgValidaComprobante", 3, 10000);
																if (lvalidacomprob!=null ) {
																	if (lvalidacomprob.isValid()) {
																		
																		if (s.exists("/pZoom.png", 0) != null) {
																			s.click(s.exists("/pZoom.png"), 1000);
																			ValidaPantalla.ZoomPagina(s, "pZoom.png", false, 6);
																			s.click(s.exists("/pZoom.png"), 2000);
																			
																		} else {
																			s.click(s.exists("/btnActualizar.png"), 1000);
																			ValidaPantalla.ZoomPagina(s, "btnActualizar.png", false, 6);
																			s.click(s.exists("/btnActualizar.png"), 2000);
																		}
																		Thread.sleep(500);	
																		
																}}else
																{  //cierra navegador
																	System.out.println("******** INI CIERRA NAVEGADOR POR MOTIVO DE INTERMITENCIA*********************");
																	lLogger.info("******** INI CIERRA NAVEGADOR POR MOTIVO DE INTERMITENCIA*********************");
																	s.type("w",Key.CTRL);
																	System.out.println("******** FNI CIERRA NAVEGADOR POR MOTIVO DE INTERMITENCIA*********************");
																	lLogger.info("******** FNI CIERRA NAVEGADOR POR MOTIVO DE INTERMITENCIA*********************");
																}
															}
														
													//}
												
													Thread.sleep(Integer.parseInt(ServicioPropertie.getPropiedad("tiempoFinal")));
													 }}
												System.out.println("******** FIN SELECCION TODOS*********************");
												lLogger.info("******** FIN SELECCION TODOS*********************");	
													}
													else if (diaDescarga.equals("TODOS"))
													{
														
														login.clickLogIn(s, "imgClickValidacion.png", 10000);
													    Thread.sleep(100);
														RobotAsignaFecha.AsignaAnio(s, Integer.toString(entry.getValue()));  //opcionAnios
													
														//Hasta aqui lleg�
														login.clickLogIn(s, "imgClickValidacion.png", 10000);
														Thread.sleep(100);
														RobotAsignaFecha.AsignaMes(s,entry.getKey()); //mesDescarga
														
														System.out.println("******** INI SELECCION TODOS*********************");
														lLogger.info("******** INI SELECCION TODOS*********************");
														
															
															for (int i =1 ; i<=RobotAsignaFecha.ValidacionDias(mesDescarga,opcionAnio) ; i++) {  // SI ES MES ACTUAL DEBE SACAR EL ULTIMO DIA  MENOS UNO DEL MES
															System.out.println("***INGRESA POR DIAS milaaaaaa***");
															
																Thread.sleep(100);
																//login.clickLogIn(s, "imgClickValidacion.png", 10000);
																
																//s.type(Key.TAB);
																//s.type(Key.TAB);
																//s.type(Key.TAB);
																//s.type(Key.TAB);
																
																conDia=i-1;
																Thread.sleep(50);
													
																if (conDia==0) {
																	s.type(Key.TAB);
																	for(int j=1;j<=31;j++) {
																	s.type(Key.UP);
																	}
																	System.out.println("*****conDia:::::"+conDia);
																} 
																Thread.sleep(100);
																RobotAsignaFecha.AsignaDia(s,diaDescarga);

																System.out.println("******** INI SELECCION POR TIPO COMPROBANTE********************");
																lLogger.info("******** INI SELECCION POR TIPO COMPROBANTE*********************");	
																s.type(Key.TAB);
																for(int c3=1;c3<=4;c3++) {
																	s.type(Key.UP);
															    }

																RobotAsignaFecha.AsignaTipoComprobante(s,tipoComprobante); 
																System.out.println("******** FIN SELECCION POR TIPO COMPROBANTE********************");
																lLogger.info("******** FIN SELECCION POR TIPO COMPROBANTE*********************");	
																
																Thread.sleep(30);
																if (s.exists("/pZoom.png", 0) != null) {
																	ValidaPantalla.ZoomPagina(s, "pZoom", true, 6);
																	s.click(s.exists("/pZoom.png"), 1000);
																} else {
																	ValidaPantalla.ZoomPagina(s, "btnActualizar", true, 6);
																	s.click(s.exists("/btnDespues.png"), 1000);
																}
																
														Thread.sleep(30);
														
														Match lvalidaPantalla= LoginPantalla.TiempoEspera(s, "conPantalla", 3, 2000);
														if (lvalidaPantalla != null) {
															if (lvalidaPantalla.isValid()) {
																Thread.sleep(1000);
																if (conDia==0) {
																	s.click(s.exists("/conPantalla.png"), 2000);
																	login.PosicionPantalla(s, 32, true);
																	login.PosicionPantalla(s, 8, false);
																}
																else if(s.exists("/imgSinComprobante1.png",10)!=null) {
																		System.out.println("sin data 1");

																		s.click(s.exists("/imgSinComprobante1.png"), 10000);
																		login.PosicionPantalla(s, 38, true);	
																		login.PosicionPantalla(s, 8, false);
																}	
																else if (s.exists("/conPantalla.png")!=null) {
																	s.click(s.exists("/conPantalla.png"), 2000);
																	login.PosicionPantalla(s, 27, true);
																	login.PosicionPantalla(s, 8, false);
															   }
															
																Thread.sleep(30); 
																
																System.out.println("******** INI ASIGNACION E INVOCACION DEL CAPCHA********************");
																lLogger.info("******** INI ASIGNACION E INVOCACION DEL CAPCHA*********************");	
																
																robotCatchap.asignaCapcha(s);	
																Thread.sleep(30);
																System.out.println("******** FIN ASIGNACION E INVOCACION DEL CAPCHA********************");
																lLogger.info("******** FIN ASIGNACION E INVOCACION DEL CAPCHA*********************");
																
																Match	lvalidaConsulta= LoginPantalla.TiempoEspera(s,"CompSegundo", 3, 120000);
																if (lvalidaConsulta!=null) {
																	if (lvalidaConsulta.isValid()) {
																		
																		Thread.sleep(30);
																		
																			if (s.exists("/imgSinComprobante2.png") != null) {

																				s.click(s.exists("/imgSinComprobante.png"), 10000);
																				login.PosicionPantalla(s, 52, true);
																			} else if (s.exists("/CompSegundo.png") != null) {
																				s.click(s.exists("/CompSegundo.png"), 10000);
																				login.PosicionPantalla(s, 44, true);
																			}
																	
																		Match lbtnDescarga = LoginPantalla.TiempoEspera(s,"btnDescargaRep", 3, 10000);
																		
																		if (lbtnDescarga != null) {
																			if (lbtnDescarga.isValid()) {
																				Thread.sleep(30); // 30
																				s.click(s.exists("/btnDescargaRep.png"), 10000);
																				
																				///////// X VALIDAR
																				try {
																					
																					System.out.println("******** INI INSERTA EN LA BASE POR EXITO EN LA DESCARGA*********************");
																					lLogger.info("******** INI INSERTA EN LA BASE POR EXITO EN LA DESCARGA *********************");
																					
																					lGestionDB.insertarLog(rucPrincipal, "EXITO: Se descargo el Anio:"+opcionAnio+" ,Mes:"+mesDescarga+ 
																										" , Dia: "+i +", Tipo Comprobante:"+tipoComprobante, "1");
																					
																					System.out.println("******** INI INSERTA EN LA BASE POR EXITO EN LA DESCARGA*********************");
																					lLogger.info("******** INI INSERTA EN LA BASE POR EXITO EN LA DESCARGA *********************");
																					
																				} catch (java.lang.Exception exception) {
																					// TODO Auto-generated catch block
																					lLogger.error(exception);
																					exception.printStackTrace();
																				}
																				
																		if (s.exists("/pZoom.png", 0) != null) {
																			s.click(s.exists("/pZoom.png"), 1000);
																			ValidaPantalla.ZoomPagina(s, "pZoom.png", false, 6);
																			s.click(s.exists("/pZoom.png"), 2000);
																			
																		} else {
																			s.click(s.exists("/btnActualizar.png"), 1000);
																			ValidaPantalla.ZoomPagina(s, "btnActualizar.png", false, 6);
																			s.click(s.exists("/btnActualizar.png"), 2000);
																		}
																		Thread.sleep(1000);
																		
																		for (int n = 0; n <= 18; n++) {
																			s.type(Key.UP);
																		}
																		
																	}}else {
																		
																		System.out.println("******** INI NO SE ENCUENTRA BOTON DESCARGA*********************");
																		lLogger.info("******** INI NO SE ENCUENTRA BOTON DESCARGA*********************");
																		
																		try {
																			
																			System.out.println("******** INI INSERTA EN LA BASE POR ERROR DE DESCARGA*********************");
																			lLogger.info("******** INI INSERTA EN LA BASE POR ERROR DE DESCARGA*********************");
																			
																			lGestionDB.insertarLog(rucPrincipal, "ERROR: No termin� con exito la descarga Anio:"+opcionAnio+" ,Mes:"+mesDescarga+ 
																					" , Dia: "+i +", Tipo Comprobante:"+tipoComprobante, "-1");
																			
																			System.out.println("******** FIN INSERTA EN LA BASE POR ERROR DE DESCARGA*********************");
																			lLogger.info("******** FIN INSERTA EN LA BASE POR ERROR DE DESCARGA*********************");
																			
																		} catch (java.lang.Exception exception) {
																			// TODO Auto-generated catch block
																			lLogger.error(exception);
																			exception.printStackTrace();
																		}
																		
																		Thread.sleep(10);
																		
																		if (s.exists("/cerrarNavegador.png", 0) != null) {
																			login.CerrarSesion(s, "cerrarNavegador.png");
																		} else if (s.exists("/btnNavegadorRojo.png", 10) != null) {
																			login.CerrarSesion(s, "btnNavegadorRojo.png");
																		}
																		System.out.println("******** FIN NO SE ENCUENTRA BOTON DESCARGA*********************");
																		lLogger.info("******** FIN NO SE ENCUENTRA BOTON DESCARGA*********************");
																		break;
																	}
																	}
																	
																	
																}else {
																	System.out.println("Cerrando el Modulo Comprobantes electronicos");
																	Thread.sleep(10);

																	if (s.exists("/cerrarNavegador.png", 0) != null) {
																		login.CerrarSesion(s, "cerrarNavegador.png");
																	} else if (s.exists("/btnNavegadorRojo.png", 10) != null) {
																		login.CerrarSesion(s, "btnNavegadorRojo.png");
																	}
																	
																	break;
																}
														      
																Thread.sleep(Integer.parseInt(ServicioPropertie.getPropiedad("tiempoFinal")));
															
																Match lverificaDia = LoginPantalla.TiempoEspera(s,"verificaDia.png", 3, 10000);
																if (lverificaDia != null) {
																	if (lverificaDia.isValid()) {
																		//verificaDia
																		s.click(s.exists("/verificaDia.png"), 10000);
																		//for (int j = 0; j < 1; j++) {
																			s.type(Key.TAB);
																			s.type(Key.TAB);
																			s.type(Key.TAB);
																			s.type(Key.TAB);
																		//}
																	}
																}
																
															 }
														
														System.out.println("******** FIN SELECCION TODOS POR DIA********************");
														lLogger.info("******** FIN SELECCION TODOS POR DIA*********************");	
															}
															
															/*System.out.println("******** INI CERRAR SESION, NAVEGADOR *********************");
														    lLogger.info("******** INI CERRAR SESION, NAVEGADOR *********************");
															for (int n = 0; n <= 25; n++) {
																s.type(Key.UP);
															}
															
															for (int n = 0; n <= 20; n++) {
																s.type(Key.RIGHT);
															}
															
															s.wait("/cerrarSesion.png", Integer.parseInt(ServicioPropertie.getPropiedad("tiempoEsperaPantalla")));
															login.CerrarSesion(s, "cerrarSesion.png");
															Thread.sleep(100);

															if (s.exists("/cerrarNavegador.png", 0) != null) {
																login.CerrarSesion(s, "cerrarNavegador.png");
															} else if (s.exists("/btnNavegadorRojo.png", 10) != null) {
																login.CerrarSesion(s, "btnNavegadorRojo.png");
															}
															App.close(ServicioPropertie.getPropiedad("rutaChrome"));
															
															System.out.println("******** FIN CERRAR SESION, NAVEGADOR *********************");
														    lLogger.info("******** FIN CERRAR SESION, NAVEGADOR *********************");
															*/
														}
														
														
													}
													
											} // fin del for lgu
											
											System.out.println("******** FIN RECORRIDO DE A�O - MES POR DEFAULT*********************");
											lLogger.info("******* FIN RECORRIDO DE A�O - MES POR DEFAULT*****************");	
											
											System.out.println("******** INI CERRAR SESION*********************");
											lLogger.info("******* INI CERRAR SESION*****************");
											
											for (int n = 0; n <= 25; n++) {
												s.type(Key.UP);
											}
											
											for (int n = 0; n <= 20; n++) {
												s.type(Key.RIGHT);
											}
											
										
											s.wait("/cerrarSesion.png", Integer.parseInt(ServicioPropertie.getPropiedad("tiempoEsperaPantalla")));
											login.CerrarSesion(s, "cerrarSesion.png");
											Thread.sleep(100);
											
											if (s.exists("/cerrarNavegador.png", 0) != null) {
												login.CerrarSesion(s, "cerrarNavegador.png");
											} else if (s.exists("/btnNavegadorRojo.png", 10) != null) {
												login.CerrarSesion(s, "btnNavegadorRojo.png");
											}
											
											App.close(ServicioPropertie.getPropiedad("rutaChrome"));
											
											System.out.println("******** FIN CERRAR SESION*********************");
											lLogger.info("******* FIN CERRAR SESION*****************");
											
										} // ** FIN DE PETICION 

												}
											}else {
												System.out.println("******** INI CERRAR PANTALLA PRINCIPAL COMPROBANTES ELECTRONICOS ********************");
												lLogger.info("******** INI CERRAR PANTALLA PRINCIPAL COMPROBANTES ELECTRONICOS ********************");	
												
												Thread.sleep(10);

												if (s.exists("/cerrarNavegador.png", 0) != null) {
													login.CerrarSesion(s, "cerrarNavegador.png");
												} else if (s.exists("/btnNavegadorRojo.png", 10) != null) {
													login.CerrarSesion(s, "btnNavegadorRojo.png");
												}
												
												System.out.println("******** FIN CERRAR PANTALLA PRINCIPAL COMPROBANTES ELECTRONICOS ********************");
												lLogger.info("******** FIN CERRAR PANTALLA PRINCIPAL COMPROBANTES ELECTRONICOS ********************");	
											}
										}
									}else {
										
										System.out.println("******** INI CERRANDO EL MODULO COMPROBANTE ELECTRONICO RECIBIDO ********************");
										lLogger.info("*********  INI CERRANDO EL MODULO COMPROBANTE ELECTRONICO RECIBIDO**********");	
										
										Thread.sleep(10);
										/*if (s.exists("/cerrarNavegador.png", 0) != null) {
											login.CerrarSesion(s, "cerrarNavegador.png");
										} else if (s.exists("/btnNavegadorRojo.png", 10) != null) {
											login.CerrarSesion(s, "btnNavegadorRojo.png");
										} */
										///////////////////validarrrr
										
										s.type("w",Key.CTRL);
										
										System.out.println("******** FIN CERRANDO EL MODULO COMPROBANTE ELECTRONICO RECIBIDO ********************");
										lLogger.info("*********  FIN CERRANDO EL MODULO COMPROBANTE ELECTRONICO RECIBIDO**********");
										
									}
									
								}
							} else {
								System.out.println("******** INI Cerrando el Modulo Comprobantes electronicos ********************");
								lLogger.info("******** INI Cerrando el Modulo Comprobantes electronicos ********************");
								
								Thread.sleep(10);
								if (s.exists("/cerrarNavegador.png", 0) != null) {
									login.CerrarSesion(s, "cerrarNavegador.png");
								} else if (s.exists("/btnNavegadorRojo.png", 10) != null) {
									login.CerrarSesion(s, "btnNavegadorRojo.png");
								}
								
								System.out.println("******** FIN Cerrando el Modulo Comprobantes electronicos ********************");
								lLogger.info("******** FIN Cerrando el Modulo Comprobantes electronicos ********************");
							}
						
						Thread.sleep(Integer.parseInt(ServicioPropertie.getPropiedad("tiempoFinal")));
					
					}
						
						System.out.println("** FIN DE COMPANIA **");
						System.out.println("** INI CONTADOR **");
						lContador=lContador+1;
						System.out.println("** FIN lContador:: **"+lContador);
						System.out.println("** INI CONTADOR **");
						
						} else if (s.exists("/tieneDeudas") != null) { //fin del la pagina principal

						System.out.println("******** INI POP-UP DEUDAS DE MES DICIEMBRE SRI ********************");
						lLogger.info("******** INI POP-UP DEUDAS DE MES DICIEMBRE SRI ********************");
						
						s.wait("/tieneDeudas.png", Integer.parseInt(ServicioPropertie.getPropiedad("tiempoEsperaPantalla")));
						s.type(Key.TAB + Key.ENTER);
						Thread.sleep(Integer.parseInt(ServicioPropertie.getPropiedad("tiempoEsperaPantalla")));

						if (s.exists("/otrasDeudas.png", 0) != null) {
							s.type(Key.TAB);
							s.type(Key.TAB);
							s.type(Key.TAB + Key.ENTER);
						}

						s.wait("/cerrarSesion.png", Integer.parseInt(ServicioPropertie.getPropiedad("tiempoEsperaPantalla")));
						login.CerrarSesion(s, "cerrarSesion.png");
						Thread.sleep(100);

						if (s.exists("/cerrarNavegador.png", 0) != null) {
							login.CerrarSesion(s, "cerrarNavegador.png");
						} else if (s.exists("/btnNavegadorRojo.png", 10) != null) {
							login.CerrarSesion(s, "btnNavegadorRojo.png");
						}
						
						App.close(ServicioPropertie.getPropiedad("rutaChrome"));
						
						System.out.println("******** FIN POP-UP DEUDAS DE MES DICIEMBRE SRI ********************");
						lLogger.info("******** FIN POP-UP DEUDAS DE MES DICIEMBRE SRI ********************");

					}else if(s.exists("/imgPageZoomLinea")!=null)	
					{ 
						
					System.out.println("******** INI SRI SESION INICIADA XZOOM 250 ********************");
					 lLogger.info("******** INI SRI SESION INICIADA XZOOM 250 *********************");
					 
						s.type(Key.TAB + Key.ENTER);
						if (s.exists("/pZoom.png", 0) != null) {
							s.click(s.exists("/pZoom.png"), 1000);
							ValidaPantalla.ZoomPagina(s, "pZoom.png", false, 6);
							s.click(s.exists("/pZoom.png"), 2000);
						} else {
							s.click(s.exists("/btnActualizar.png"), 1000);
							ValidaPantalla.ZoomPagina(s, "btnActualizar.png", false, 6);
							s.click(s.exists("/btnActualizar.png"), 2000);
						}
						Thread.sleep(500);

						 if(s.exists("/pantallaDeudaSegundo.png",10) != null){
							   System.out.println("ingresa a 2da pantalla ********");
								s.type(Key.TAB);
								s.type(Key.TAB);
								s.type(Key.TAB + Key.ENTER);
						}
						
						
					//s.wait("/cerrarSesion.png", Integer.parseInt(ServicioPropertie.getPropiedad("tiempoEsperaPantalla")));
						if (s.exists("/cerrarSesion.png")!=null) {
							
							s.wait("/cerrarSesion.png", Integer.parseInt(ServicioPropertie.getPropiedad("tiempoEsperaPantalla")));
							login.CerrarSesion(s, "cerrarSesion.png");
							Thread.sleep(100);

						}
						 
						/*if (s.exists("/cerrarNavegador.png", 0) != null) {
							login.CerrarSesion(s, "cerrarNavegador.png");
						} else if (s.exists("/btnNavegadorRojo.png", 10) != null) {
							login.CerrarSesion(s, "btnNavegadorRojo.png");
						}
						App.close(ServicioPropertie.getPropiedad("rutaChrome"));
					*/
							s.type("w",Key.CTRL);
						
						System.out.println("******** FIN SRI SESION INICIADA XZOOM 250 ********************");
						 lLogger.info("******** FIN SRI SESION INICIADA XZOOM 250 *********************");
						
					} else if (s.exists("zoomPendientes") != null) {
						
						 System.out.println("******** INI SESION INICIADA XZOOM 250 ********************");
						 lLogger.info("******** INI SESION INICIADA XZOOM 250 *********************");
						
						if (s.exists("/pZoom.png", 0) != null) {
							s.click(s.exists("/pZoom.png"), 1000);
							ValidaPantalla.ZoomPagina(s, "pZoom.png", false, 6);
							s.click(s.exists("/pZoom.png"), 2000);
						} else {
							s.click(s.exists("/btnActualizar.png"), 1000);
							ValidaPantalla.ZoomPagina(s, "btnActualizar.png", false, 6);
							s.click(s.exists("/btnActualizar.png"), 2000);
						}

						Thread.sleep(Integer.parseInt(ServicioPropertie.getPropiedad("tiempoEsperaPantalla")));

						if (s.exists("/cerrarNavegador.png", 0) != null) {
							login.CerrarSesion(s, "cerrarNavegador.png");
						} else if (s.exists("/btnNavegadorRojo.png", 10) != null) {
							login.CerrarSesion(s, "btnNavegadorRojo.png");
						}
						
						App.close(ServicioPropertie.getPropiedad("rutaChrome"));
						
						System.out.println("******** FIN SESION INICIADA XZOOM 250 ********************");
						lLogger.info("******** FIN SESION INICIADA XZOOM 250 *********************");
					} 
					
					 else if (s.exists("/imgSriNotLogin.png") != null) {
						 
						 System.out.println("******** INI SESION NO INICIADA POR XZOOM 250 ********************");
						 lLogger.info("******** INI SESION NO INICIADA POR XZOOM 250 *********************");
							
						if (s.exists("/pZoom.png", 0) != null) {
							s.click(s.exists("/pZoom.png"), 1000);
							ValidaPantalla.ZoomPagina(s, "pZoom.png", false, 6);
							s.click(s.exists("/pZoom.png"), 2000);
						} else {
							s.click(s.exists("/btnActualizar.png"), 1000);
							ValidaPantalla.ZoomPagina(s, "btnActualizar.png", false, 6);
							s.click(s.exists("/btnActualizar.png"), 2000);
						}

						Thread.sleep(1000);
						
						if (s.exists("/cerrarNavegador.png", 0) != null) {
							login.CerrarSesion(s, "cerrarNavegador.png");
						} else if (s.exists("/btnNavegadorRojo.png", 10) != null) {
							login.CerrarSesion(s, "btnNavegadorRojo.png");
						}
						
						App.close(ServicioPropertie.getPropiedad("rutaChrome"));
					
						System.out.println("******** FIN SESION NO INICIADA POR XZOOM 250 ********************");
						lLogger.info("******** FIN SESION NO INICIADA POR XZOOM 250 *********************");
						
					} else if (s.exists("/imgSRIsinservicioZoom")!=null) {
						
						System.out.println("******** INI PAGINA SRI SIN SERVICIO XZOOM 250 ********************");
						lLogger.info("******** INI PAGINA SRI SIN SERVICIO XZOOM 250 *********************");	
						
						if (s.exists("/pZoom.png", 0) != null) {
							s.click(s.exists("/pZoom.png"), 1000);
							ValidaPantalla.ZoomPagina(s, "pZoom.png", false, 6);
							s.click(s.exists("/pZoom.png"), 2000);
						} else {
							s.click(s.exists("/btnActualizar.png"), 1000);
							ValidaPantalla.ZoomPagina(s, "btnActualizar.png", false, 6);
							s.click(s.exists("/btnActualizar.png"), 2000);
						}

						Thread.sleep(100);
						
						if (s.exists("/cerrarNavegador.png", 0) != null) {
							login.CerrarSesion(s, "cerrarNavegador.png");
						} else if (s.exists("/btnNavegadorRojo.png", 10) != null) {
							login.CerrarSesion(s, "btnNavegadorRojo.png");
						}
						
						App.close(ServicioPropertie.getPropiedad("rutaChrome"));
						
						System.out.println("******** FIN PAGINA SRI SIN SERVICIO XZOOM 250 ********************");
						lLogger.info("******** FIN PAGINA SRI SIN SERVICIO XZOOM 250 *********************");	
					}
					else if (s.exists("/pageMantenimiento") != null) {
						
						System.out.println("******** INI PAGINA SRI SE ENCUENTRA EN MANTENIMIENTO********************");
						lLogger.info("******** INI PAGINA SRI SE ENCUENTRA EN MANTENIMIENTO*********************");	
						

						/*Thread.sleep(Integer.parseInt(ServicioPropertie.getPropiedad("tiempoEsperaPantalla")));

						if (s.exists("/cerrarNavegador", 0) != null) {
							login.CerrarSesion(s, "cerrarNavegador");
						} else if (s.exists("/btnNavegadorRojo", 10) != null) {
							login.CerrarSesion(s, "btnNavegadorRojo");
						}
						
						App.close(ServicioPropertie.getPropiedad("rutaChrome")); */
						
						s.type("w",Key.CTRL);
						
						System.out.println("******** FIN PAGINA SRI SE ENCUENTRA EN MANTENIMIENTO********************");
						lLogger.info("******** FIN PAGINA SRI SE ENCUENTRA EN MANTENIMIENTO*********************");	

					} else if (s.exists("/loginSriZoom.png") != null){
						
						System.out.println("******** INI RESTAURANDO Y CERRANDO SESION POR MOTIVOS DE ITERMITENCIA DE SRI********************");
						lLogger.info("******** INI RESTAURANDO Y CERRANDO SESION POR MOTIVOS DE ITERMITENCIA DE SRI*********************");	
						
						if (s.exists("/pZoom.png", 0) != null) {
							s.click(s.exists("/pZoom.png"), 1000);
							ValidaPantalla.ZoomPagina(s, "pZoom.png", false, 6);
							s.click(s.exists("/pZoom.png"), 2000);
							
						} else {
							s.click(s.exists("/btnActualizar.png"), 1000);
							ValidaPantalla.ZoomPagina(s, "btnActualizar.png", false, 6);
							s.click(s.exists("/btnActualizar.png"), 2000);
						}
						
						if (s.exists("/imgNuevaDeclaracion.png")!=null) {
							s.wait("/imgNuevaDeclaracion.png", Integer.parseInt(ServicioPropertie.getPropiedad("tiempoEsperaPantalla")));
							s.type(Key.TAB + Key.ENTER);
							
							if(s.exists("/pantallaDeudaSegundo.png",0) != null){
								s.type(Key.TAB);
								s.type(Key.TAB);
								s.type(Key.TAB + Key.ENTER);
							}
						}
						
						s.wait("/cerrarSesion.png", Integer.parseInt(ServicioPropertie.getPropiedad("tiempoEsperaPantalla")));
						login.CerrarSesion(s, "cerrarSesion.png");
						Thread.sleep(100);
						
						if (s.exists("/cerrarNavegador.png", 0) != null) {
							login.CerrarSesion(s, "cerrarNavegador.png");
						} else if (s.exists("/btnNavegadorRojo.png", 10) != null) {
							login.CerrarSesion(s, "btnNavegadorRojo.png");
						}
						
						App.close(ServicioPropertie.getPropiedad("rutaChrome"));
						
						System.out.println("******** FIN RESTAURANDO Y CERRANDO SESION POR MOTIVOS DE ITERMITENCIA DE SRI********************");
						lLogger.info("******** FIN RESTAURANDO Y CERRANDO SESION POR MOTIVOS DE ITERMITENCIA DE SRI*********************");	
						
					}else if (s.exists("/imgSRIlogin")!=null) {
						
						System.out.println("******** INI CERRANDO SESION POR MOTIVOS DE ITERMITENCIA DE SRI********************");
						lLogger.info("******** INI CERRANDO SESION POR MOTIVOS DE ITERMITENCIA DE SRI*********************");	
						
						
						
						if (s.exists("/imgNuevaDeclaracion.png")!=null) {
							s.wait("/imgNuevaDeclaracion.png", Integer.parseInt(ServicioPropertie.getPropiedad("tiempoEsperaPantalla")));
							s.type(Key.TAB + Key.ENTER);
							
							/*if(s.exists("/pantallaDeudaSegundo",0) != null){
								s.type(Key.TAB);
								s.type(Key.TAB);
								s.type(Key.TAB + Key.ENTER);
							}*/
							 if(s.exists("/pantallaDeudaSegundo.png",10) != null){
								   System.out.println("ingresa a 2da pantalla ********");
									s.type(Key.TAB);
									s.type(Key.TAB);
									s.type(Key.TAB + Key.ENTER);
								}
							
						}
						s.wait("/cerrarSesion.png", Integer.parseInt(ServicioPropertie.getPropiedad("tiempoEsperaPantalla")));
						login.CerrarSesion(s, "cerrarSesion.png");
						Thread.sleep(100);
						
						if (s.exists("/cerrarNavegador.png") != null) {
							login.CerrarSesion(s, "cerrarNavegador.png");
						} else if (s.exists("/btnNavegadorRojo.png", 10) != null) {
							login.CerrarSesion(s, "btnNavegadorRojo.png");
						}
						
						App.close(ServicioPropertie.getPropiedad("rutaChrome"));
						System.out.println("******** FIN CERRANDO SESION POR MOTIVOS DE ITERMITENCIA DE SRI********************");
						lLogger.info("******** FIN CERRANDO SESION POR MOTIVOS DE ITERMITENCIA DE SRI*********************");	
						
					}
					else {
						System.out.println("******** INI CERRAR NAVEGADOR POR MOTIVOS DE INTERMITENCIA DEL SRI ********************");
						lLogger.info("******** INI CERRAR NAVEGADOR POR MOTIVOS DE INTERMITENCIA DEL SRI ********************");
						
						/*Thread.sleep(Integer.parseInt(ServicioPropertie.getPropiedad("tiempoEsperaPantalla")));

						if (s.exists("/cerrarNavegador", 0) != null) {
							login.CerrarSesion(s, "cerrarNavegador");
						} else if (s.exists("/btnNavegadorRojo", 10) != null) {
							login.CerrarSesion(s, "btnNavegadorRojo");
						}
						
						App.close(ServicioPropertie.getPropiedad("rutaChrome"));*/
						s.type("w",Key.CTRL);
						
						System.out.println("******** INI CERRAR NAVEGADOR POR MOTIVOS DE INTERMITENCIA DEL SRI ********************");
						lLogger.info("******** INI CERRAR NAVEGADOR POR MOTIVOS DE INTERMITENCIA DEL SRI ********************");
					}
					
					
					
				}catch(Exception lError) {
					lError.printStackTrace();
					//System.out.println("Procesando la compania"+lCompania);
					lLogger.error(lError);
					System.out.println(":::INI FINALIZAR CHROME INCIALIZADO:::");
					s.type("w",Key.CTRL);
					System.out.println(":::FIN FINALIZAR CHROME INCIALIZADO:::");
				}
				
			  }
				System.out.println("** FIN DE SUSCRIPTOR **");
			}
			
            
			
	}catch(Exception lError)
	{   lLogger.error(lError);
		lError.printStackTrace();
		
	} catch (InterruptedException lEInterruptedException) {
		 lLogger.error(lEInterruptedException);
		// TODO Auto-generated catch block
		 lEInterruptedException.printStackTrace();
		
	} catch (FindFailed lEFindFailed) {
		// TODO Auto-generated catch block
		lLogger.error(lEFindFailed);
		// TODO Auto-generated catch block
		 lEFindFailed.printStackTrace();
		 
	} catch (ExcepcionEncriptacion lError) {
		// TODO Auto-generated catch block
		lLogger.error(lError);
		lError.printStackTrace();
	} finally {
		
		System.out.println("-------------------KILL CHROME------------------");
		lLogger.info("-------------------KILL CHROME------------------");
		Runtime rt1 = Runtime.getRuntime();
		Process pr1 = rt1.exec("taskkill /F /IM chrome.exe /T");
		System.out.println("-------------------KILL CHROME------------------");
		lLogger.info("-------------------KILL CHROME------------------");
		
	}
	}
}
