package com.corlasosa.pruebas;

import org.sikuli.script.FindFailed;
import org.sikuli.script.Screen;

public class ValidaPantalla {
	
	public static void ZoomPagina(Screen pScreen,String pNombreImagen,boolean pAumenta ,int pNumLimite) throws FindFailed, InterruptedException {

		  if(pAumenta)
			  pScreen.click(pScreen.exists("/" + pNombreImagen), 2000);
		
	                   // 6 por defecto
		for(int i=0; i<pNumLimite;i++) {
			
	    if(pAumenta)
			
	    	pScreen.click(pScreen.exists("/botonMas"), 100000);
	    else
	    	pScreen.click(pScreen.exists("/botonMenos"), 10000);
	    
		Thread.sleep(100);

		}
	
	}

}
