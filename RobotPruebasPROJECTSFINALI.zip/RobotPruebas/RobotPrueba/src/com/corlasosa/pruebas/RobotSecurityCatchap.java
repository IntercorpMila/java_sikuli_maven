package com.corlasosa.pruebas;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.Logger;
import org.sikuli.script.App;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Match;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import util.ServicioPropertie;
import com.tigervnc.rdr.Exception;

public class RobotSecurityCatchap extends LoginPantalla {
	
	public static String lNombreImagen=null;
	public static String lValueImagen=null;
	
	private static Logger lLogger = Logger.getLogger(RobotSecurityCatchap.class);
	
	public void asignaCapcha(Screen s) throws InterruptedException, FindFailed {
		lNombreImagen=null;
		lValueImagen=null;
   
		HashMap<String, String> listaImagenesCapcha = new HashMap<String, String>();
		listaImagenesCapcha.put("zoomLetraArbol", "zoomBotonArbol");
		listaImagenesCapcha.put("zoomLetraBandera", "zoomBotonBandera");
		listaImagenesCapcha.put("zoomLetraCamara", "zoomBotonCamara");
		listaImagenesCapcha.put("zoomLetraCamion", "zoomBotonCamion");
		listaImagenesCapcha.put("zoomLetraCamiseta", "zoomBotonCamiseta");
		listaImagenesCapcha.put("zoomLetraCandado", "zoomBotonCandado");
		listaImagenesCapcha.put("zoomLetraAeroplano", "zoomBotonAeroplano");
		listaImagenesCapcha.put("zoomLetraCarpeta", "zoomBotonCarpeta");
		listaImagenesCapcha.put("zoomLetraCasa", "zoomBotonCasa");
		listaImagenesCapcha.put("zoomLetraClip", "zoomBotonClip");
		listaImagenesCapcha.put("zoomLetraComputadora", "zoomBotonComputadora");
		listaImagenesCapcha.put("zoomLetraEtiqueta", "zoomBotonEtiqueta");
		listaImagenesCapcha.put("zoomLetraFoco", "zoomBotonFoco");
		listaImagenesCapcha.put("zoomLetraGafas", "zoomBotonGafa");
		listaImagenesCapcha.put("zoomLetraGato", "zoomBotonGato");
		listaImagenesCapcha.put("zoomLetraGlobo", "zoomBotonGlobo");
		listaImagenesCapcha.put("zoomLetraGrafico", "zoomBotonGrafico");
		listaImagenesCapcha.put("zoomLetraHoja", "zoomBotonHoja");
		listaImagenesCapcha.put("zoomLetraImpresora", "zoomBotonImpresora");
		listaImagenesCapcha.put("zoomLetraLapiz", "zoomBotonLapiz");
		listaImagenesCapcha.put("zoomLetraLlave", "zoomBotonLlave");
		listaImagenesCapcha.put("zoomLetraLupa", "zoomBotonLupa");
		listaImagenesCapcha.put("zoomLetraMujer", "zoomBotonMujer");
		listaImagenesCapcha.put("zoomLetraMundo", "zoomBotonMundo");
		listaImagenesCapcha.put("zoomLetraNotaMusical", "zoomBotonNotaMusical");
		listaImagenesCapcha.put("zoomLetraNube", "zoomBotonNube");
		listaImagenesCapcha.put("zoomLetraOjo", "zoomBotonOjo");
		listaImagenesCapcha.put("zoomLetraPantalon", "zoomBotonPantalon");
		listaImagenesCapcha.put("zoomLetraPie", "zoomBotonPie");
		listaImagenesCapcha.put("zoomLetraReloj", "zoomBotonReloj");
		listaImagenesCapcha.put("zoomLetraRobot", "zoomBotonRobot");
		listaImagenesCapcha.put("zoomLetraSilla", "zoomBotonSilla");
		listaImagenesCapcha.put("zoomLetraSobre", "zoomBotonSobre");
		listaImagenesCapcha.put("zoomLetraSombrilla", "zoomBotonSombrilla");
		listaImagenesCapcha.put("zoomLetraTijera", "zoomBotonTijera");
		listaImagenesCapcha.put("zoomLetraCarro", "zoomBotonCarro");
		listaImagenesCapcha.put("zoomLetraHombre", "zoomBotonHombre");
		LoginPantalla login=new LoginPantalla();
		
		Thread.sleep(1000);
		
		System.out.println("******* INI RECORRIDO DEL PATRON IMAGENES DEL CAPCHA *******************");
		lLogger.info("******* INI RECORRIDO DEL PATRON IMAGENES DEL CAPCHA ********************");
		
		  final List<Thread> threads      = new ArrayList<Thread>();
		for (Map.Entry<String, String> captcha : listaImagenesCapcha
				.entrySet()) {
			System.out.println("******* RECORRIENDO hilos************** "+captcha.getKey());
			lLogger.info("******* INI RECORRIDO DEL PATRON IMAGENES DEL CAPCHA ********************"+captcha.getKey());
			
			
		
			 Runnable lRunnable= createRunnable (false, s,  captcha.getKey() , captcha.getValue());
		     threads.add( new Thread(lRunnable));
		
			
		}
		for( Thread t : threads ) { 
		      t.start();
		    }
		    for( Thread t : threads ) { 
		      t.join();	    
		    }
		    
		    System.out.println("Esta es la imagen "+lNombreImagen);
		    

			
			System.out.println("IMAGEN SELECCIONADA  "+lNombreImagen);
			lLogger.info("IMAGEN SELECCIONADA  "+lNombreImagen);
			System.out.println("********PASO SELECCION DE IMAGEN*********");
			
			Thread.sleep(30);
			
			Match lvalidaCatcha= LoginPantalla.TiempoEspera(s, lValueImagen, 3, 100000);
			if (lvalidaCatcha != null) {
				if (lvalidaCatcha.isValid()) {
		     Thread.sleep(30);
	    	s.click("/" +lValueImagen, 2000); 
			Thread.sleep(30);
			
			
			
			Match	lvalidRetencion= LoginPantalla.TiempoEspera(s,"CompSegundo", 3, 120000);
				
			if (lvalidRetencion!=null) {
				if (lvalidRetencion.isValid()) {
					
				  if(s.exists("/imgSinComprobante2")!=null) {

					 s.click(s.exists("/imgSinComprobante2"), 10000);
					 login.PosicionPantalla(s, 50, true);		
				  }	
				  else if (s.exists("/CompSegundo")!=null) {

						s.click(s.exists("/CompSegundo"), 10000);
						login.PosicionPantalla(s, 32, true);
				    }
						s.wait("/zoomBotonConsultar", 30);
						Thread.sleep(2000);//5000 
						s.click(s.exists("/btnConsultar"), 400);
						//Thread.sleep(100);//5000
						//login.PosicionPantalla(s, 5, false);
			}}else {
				System.out.println("******* INI NO FINALIZO CON EXITO RECORRIDO DE CAPCHA POR ITERMITENCIA SRI *******************");
				lLogger.info("******* INI NO FINALIZO CON EXITO RECORRIDO DE CAPCHA POR ITERMITENCIA SRI ********************");
				
				Thread.sleep(10);
				if (s.exists("/cerrarNavegador", 0) != null) {
					login.CerrarSesion(s, "cerrarNavegador");
				} else if (s.exists("/btnNavegadorRojo", 10) != null) {
					login.CerrarSesion(s, "btnNavegadorRojo");
				}
				
				App.close(ServicioPropertie.getPropiedad("rutaChrome"));
				
				System.out.println("******* FIN NO FINALIZO CON EXITO RECORRIDO DE CAPCHA POR ITERMITENCIA SRI *******************");
				lLogger.info("******* FIN NO FINALIZO CON EXITO RECORRIDO DE CAPCHA POR ITERMITENCIA SRI ********************");
			}
			
				}}else {
					
					System.out.println("******* INI NO FINALIZO CON EXITO RECORRIDO DE CAPCHA POR ITERMITENCIA SRI *******************");
					lLogger.info("******* INI NO FINALIZO CON EXITO RECORRIDO DE CAPCHA POR ITERMITENCIA SRI ********************");
					
					Thread.sleep(10);
					if (s.exists("/cerrarNavegador", 0) != null) {
						login.CerrarSesion(s, "cerrarNavegador");
					} else if (s.exists("/btnNavegadorRojo", 10) != null) {
						login.CerrarSesion(s, "btnNavegadorRojo");
					}
					
					App.close(ServicioPropertie.getPropiedad("rutaChrome"));
					
					System.out.println("******* FIN NO FINALIZO CON EXITO RECORRIDO DE CAPCHA POR ITERMITENCIA SRI *******************");
					lLogger.info("******* FIN NO FINALIZO CON EXITO RECORRIDO DE CAPCHA POR ITERMITENCIA SRI ********************");
				}

		
		
	
		
	}	
	
	private static Runnable createRunnable(final boolean pExiste, Screen pScreen, String pCaptcha, String pCaptchaValue){

	    Runnable aRunnable = new Runnable(){
	        public void run(){
	        	   	 
		        	 
		        	 ////FIN DE LA CONSULTA
		        	try { 
		        		Pattern scroll = new Pattern("/" + pCaptcha);
		    			Pattern scrollCheck = scroll.exact();

						if (pScreen.exists(scrollCheck,0) != null) {
							System.out.print("Entro"+scrollCheck.getFileURL());
							lNombreImagen=pCaptcha;
							lValueImagen=pCaptchaValue;
						}
						
							
		                Thread.sleep( 500 );
		              } catch( InterruptedException ie ) {
		                throw new RuntimeException( ie );
		              }
		        	
		            
		          }
		        
	          
	        
	    };

	    return aRunnable;

	}
	
	public void asignaCapchaR(Screen s) throws InterruptedException, FindFailed {

		
		lNombreImagen=null; 
		lValueImagen=null;


		HashMap<String, String> listaImagenesCapcha = new HashMap<String, String>();
		listaImagenesCapcha.put("zoomLetraArbol", "zoomBotonArbol");
		listaImagenesCapcha.put("zoomLetraBandera", "zoomBotonBandera");
		listaImagenesCapcha.put("zoomLetraCamara", "zoomBotonCamara");
		listaImagenesCapcha.put("zoomLetraCamion", "zoomBotonCamion");
		listaImagenesCapcha.put("zoomLetraCamiseta", "zoomBotonCamiseta");
		listaImagenesCapcha.put("zoomLetraCandado", "zoomBotonCandado");
		listaImagenesCapcha.put("zoomLetraAeroplano", "zoomBotonAeroplano");
		listaImagenesCapcha.put("zoomLetraCarpeta", "zoomBotonCarpeta");
		listaImagenesCapcha.put("zoomLetraCasa", "zoomBotonCasa");
		listaImagenesCapcha.put("zoomLetraClip", "zoomBotonClip");
		listaImagenesCapcha.put("zoomLetraComputadora", "zoomBotonComputadora");
		listaImagenesCapcha.put("zoomLetraEtiqueta", "zoomBotonEtiqueta");
		listaImagenesCapcha.put("zoomLetraFoco", "zoomBotonFoco");
		listaImagenesCapcha.put("zoomLetraGafas", "zoomBotonGafa");
		listaImagenesCapcha.put("zoomLetraGato", "zoomBotonGato");
		listaImagenesCapcha.put("zoomLetraGlobo", "zoomBotonGlobo");
		listaImagenesCapcha.put("zoomLetraGrafico", "zoomBotonGrafico");
		listaImagenesCapcha.put("zoomLetraHoja", "zoomBotonHoja");
		listaImagenesCapcha.put("zoomLetraImpresora", "zoomBotonImpresora");
		listaImagenesCapcha.put("zoomLetraLapiz", "zoomBotonLapiz");
		listaImagenesCapcha.put("zoomLetraLlave", "zoomBotonLlave");
		listaImagenesCapcha.put("zoomLetraLupa", "zoomBotonLupa");
		listaImagenesCapcha.put("zoomLetraMujer", "zoomBotonMujer");
		listaImagenesCapcha.put("zoomLetraMundo", "zoomBotonMundo");
		listaImagenesCapcha.put("zoomLetraNotaMusical", "zoomBotonNotaMusical");
		listaImagenesCapcha.put("zoomLetraNube", "zoomBotonNube");
		listaImagenesCapcha.put("zoomLetraOjo", "zoomBotonOjo");
		listaImagenesCapcha.put("zoomLetraPantalon", "zoomBotonPantalon");
		listaImagenesCapcha.put("zoomLetraPie", "zoomBotonPie");
		listaImagenesCapcha.put("zoomLetraReloj", "zoomBotonReloj");
		listaImagenesCapcha.put("zoomLetraRobot", "zoomBotonRobot");
		listaImagenesCapcha.put("zoomLetraSilla", "zoomBotonSilla");
		listaImagenesCapcha.put("zoomLetraSobre", "zoomBotonSobre");
		listaImagenesCapcha.put("zoomLetraSombrilla", "zoomBotonSombrilla");
		listaImagenesCapcha.put("zoomLetraTijera", "zoomBotonTijera");
		listaImagenesCapcha.put("zoomLetraCarro", "zoomBotonCarro");
		listaImagenesCapcha.put("zoomLetraHombre", "zoomBotonHombre");
		LoginPantalla login=new LoginPantalla();
		
		Thread.sleep(1000);
		
		System.out.println("******** INI RECORRIDO DEL PATRON IMAGENES DEL CAPCHA ********************");
		lLogger.info("******** INI RECORRIDO DEL PATRON IMAGENES DEL CAPCHA *********************");
		
		for (Map.Entry<String, String> captcha : listaImagenesCapcha
				.entrySet()) {
			try {
				
				
				Pattern scroll = new Pattern("/" + captcha.getKey());
				Pattern scrollCheck = scroll.exact();

				if (s.exists(scrollCheck) != null) {
					
					
					Match lvalidaCatcha= LoginPantalla.TiempoEspera(s, captcha.getValue(), 3, 10000);
					if (lvalidaCatcha != null) {
						if (lvalidaCatcha.isValid()) {
					
			    	s.click("/" + captcha.getValue(), 4000); 
					Thread.sleep(30);
					
					Match	lvalidRetencion= LoginPantalla.TiempoEspera(s,"CompSegundo", 3, 120000);
					
					if (lvalidRetencion!=null) {
						if (lvalidRetencion.isValid()) {
							
						  if(s.exists("/imgSinComprobante2")!=null) {

							 s.click(s.exists("/imgSinComprobante2"), 10000);
							 login.PosicionPantalla(s, 50, true);		
						  }	
						  else if (s.exists("/CompSegundo")!=null) {

								s.click(s.exists("/CompSegundo"), 10000);
								login.PosicionPantalla(s, 32, true);
						    }
								s.wait("/zoomBotonConsultar", 30);
								Thread.sleep(1000);//5000 
								s.click(s.exists("/btnConsultar"), 400);
								//Thread.sleep(100);//5000
								//login.PosicionPantalla(s, 5, false);
					}}
					
						}}else {
							
							System.out.println("******** INI NO FINALIZO CON EXITO RECORRIDO DE CAPCHA POR ITERMITENCIA SRI ********************");
							lLogger.info("******** INI NO FINALIZO CON EXITO RECORRIDO DE CAPCHA POR ITERMITENCIA SRI *********************");
							
							Thread.sleep(10);
							if (s.exists("/cerrarNavegador", 0) != null) {
								login.CerrarSesion(s, "cerrarNavegador");
							} else if (s.exists("/btnNavegadorRojo", 10) != null) {
								login.CerrarSesion(s, "btnNavegadorRojo");
							}
							
							App.close(ServicioPropertie.getPropiedad("rutaChrome"));
							
							System.out.println("******** FIN NO FINALIZO CON EXITO RECORRIDO DE CAPCHA POR ITERMITENCIA SRI ********************");
							lLogger.info("******** FIN NO FINALIZO CON EXITO RECORRIDO DE CAPCHA POR ITERMITENCIA SRI *********************");
						}
					break;
				}
				
			System.out.println("******** FIN RECORRIDO DEL PATRON IMAGENES DEL CAPCHA ********************");
			lLogger.info("******** FIN RECORRIDO DEL PATRON IMAGENES DEL CAPCHA *********************");	
			
			} catch (Exception e) {
				lLogger.error(e);
				e.printStackTrace();
			}
		} 
		
	}

}
