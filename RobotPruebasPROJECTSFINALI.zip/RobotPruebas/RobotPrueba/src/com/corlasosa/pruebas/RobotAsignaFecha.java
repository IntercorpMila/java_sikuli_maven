package com.corlasosa.pruebas;

import java.util.Calendar;

import org.apache.log4j.Logger;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Key;
import org.sikuli.script.Screen;

import com.tigervnc.rdr.Exception;

public class RobotAsignaFecha {

	private static Logger lLogger = Logger.getLogger(RobotAsignaFecha.class);
	
	public static void AsignaAnio(Screen pScrren, String pAnio)  {
	try
	{
		System.out.println("******** INI SELECCION DE ANIO CONFIGURADO *********************");
		lLogger.info("******** INI SELECCION DE ANIO CONFIGURADO *********************");
		
		pScrren.type(Key.TAB);
		for (int c1 = 0; c1 <= 5; c1++) {
			pScrren.type(Key.UP);
		}
		int cantAnio = 0;
		switch (pAnio) {
		case "2019":
			
			System.out.println("******** INI CONFIGURACION ANIO: *"+pAnio+"********************");
			lLogger.info("******** INI CONFIGURACION ANIO: *"+pAnio+"********************");
				Thread.sleep(3000);
			if (pScrren.exists("/btn2019.png", 10) != null) {
				pScrren.click("/btn2019.png", 10000);
				// accionCon2019
				pScrren.click("/accionCon2019.png", 10000);
			}
			System.out.println("******** FIN CONFIGURACION ANIO: *"+pAnio+"********************");
			lLogger.info("******** FIN CONFIGURACION ANIO: *"+pAnio+"********************");
			break;
			

		case "2018":
			System.out.println("******** INI CONFIGURACION ANIO: *"+pAnio+"********************");
			lLogger.info("******** INI CONFIGURACION ANIO: *"+pAnio+"********************");
			Thread.sleep(3000);
			if (pScrren.exists("/btn2019.png", 10) != null) {
				pScrren.click("/btn2019.png", 10000);
				cantAnio = 2019 - Integer.parseInt(pAnio);
				System.out.println("cantidad::" + cantAnio);
				for (int i = 1; i <= cantAnio; i++) {
					pScrren.type(Key.DOWN);
					Thread.sleep(200);
				}
				pScrren.type(Key.ENTER);
			System.out.println("******** FIN CONFIGURACION ANIO: *"+pAnio+"********************");
			lLogger.info("******** FIN CONFIGURACION ANIO: *"+pAnio+"********************");
				break;
			}
		case "2017":
			System.out.println("******** INI CONFIGURACION ANIO: *"+pAnio+"********************");
			lLogger.info("******** INI CONFIGURACION ANIO: *"+pAnio+"********************");
			Thread.sleep(3000);
			if (pScrren.exists("/btn2019.png", 10) != null) {
				pScrren.click("/btn2019.png", 10000);
				cantAnio = 2019 - Integer.parseInt(pAnio);
				System.out.println("cantidad::" + cantAnio);
				for (int i = 1; i <= cantAnio; i++) {
					pScrren.type(Key.DOWN);
					Thread.sleep(200);
				}
				pScrren.type(Key.ENTER);
			System.out.println("******** FIN CONFIGURACION ANIO: *"+pAnio+"********************");
			lLogger.info("******** FIN CONFIGURACION ANIO: *"+pAnio+"********************");
				break;
			}
		case "2016":
			System.out.println("******** INI CONFIGURACION ANIO: *"+pAnio+"********************");
			lLogger.info("******** INI CONFIGURACION ANIO: *"+pAnio+"********************");
			Thread.sleep(3000);
			if (pScrren.exists("/btn2019.png", 10) != null) {
				pScrren.click("/btn2019.png", 10000);
				cantAnio = 2019 - Integer.parseInt(pAnio);
				System.out.println("cantidad::" + cantAnio);
				for (int i = 1; i <= cantAnio; i++) {
					pScrren.type(Key.DOWN);
					Thread.sleep(200);
				}
				pScrren.type(Key.ENTER);
			System.out.println("******** FIN CONFIGURACION ANIO: *"+pAnio+"********************");
			lLogger.info("******** FIN CONFIGURACION ANIO: *"+pAnio+"********************");
				break;
			}
		case "2015":
			System.out.println("******** INI CONFIGURACION ANIO: *"+pAnio+"********************");
			lLogger.info("******** INI CONFIGURACION ANIO: *"+pAnio+"********************");
			Thread.sleep(3000);
			if (pScrren.exists("/btn2019.png", 10) != null) {
				pScrren.click("/btn2019.png", 10000);
				cantAnio = 2019 - Integer.parseInt(pAnio);
				System.out.println("cantidad::" + cantAnio);
				for (int i = 1; i <= cantAnio; i++) {
					pScrren.type(Key.DOWN);
					Thread.sleep(200);
				}
				pScrren.type(Key.ENTER);
			System.out.println("******** FIN CONFIGURACION ANIO: *"+pAnio+"********************");
			lLogger.info("******** FIN CONFIGURACION ANIO: *"+pAnio+"********************");
				break;
			}
		}
		
		System.out.println("******** FIN SELECCION DE ANIO CONFIGURADO *********************");
		lLogger.info("******** FIN SELECCION DE ANIO CONFIGURADO *********************");
		
		}catch(Exception lError)
		{   lLogger.error(lError);
		    lError.printStackTrace();
		} catch (InterruptedException lEInterruptedException) {
			 lLogger.error(lEInterruptedException);
			 lEInterruptedException.printStackTrace();
	    } catch (FindFailed lEFindFailed) {
			 lLogger.error(lEFindFailed);
			 lEFindFailed.printStackTrace();
		}
	}
	
	public static void AsignaMes(Screen pScrren, String pMes)  {
		int cmes = 0;
	
		System.out.println("******** INI EL DIA NO SE ENCUENTRA CONFIGURADO *********************");
		lLogger.info("******** INI EL DIA NO SE ENCUENTRA CONFIGURADO *********************");
		
		pScrren.type(Key.TAB);
		pScrren.type(Key.TAB);
		
		switch (pMes) {
		
		case "01":
			System.out.println("******** INI CONFIGURACION MES: *"+pMes+"********************");
			lLogger.info("******** INI CONFIGURACION MES: *"+pMes+"********************");

			for (int c1 = 0; c1 <= 11; c1++) {
				pScrren.type(Key.UP);
			}
			System.out.println("******** FIN CONFIGURACION MES: *"+pMes+"********************");
			lLogger.info("******** FIN CONFIGURACION MES: *"+pMes+"********************");
			break;

		case "02":
			System.out.println("******** INI CONFIGURACION MES: *"+pMes+"********************");
			lLogger.info("******** INI CONFIGURACION MES: *"+pMes+"********************");
			cmes = 1;

			for (int c1 = 0; c1 <= 11; c1++) {
				pScrren.type(Key.UP);
			}

			for (int c1 = 0; c1 < cmes; c1++) {
				pScrren.type(Key.DOWN);
			}
			System.out.println("******** FIN CONFIGURACION MES: *"+pMes+"********************");
			lLogger.info("******** FIN CONFIGURACION MES: *"+pMes+"********************");			
			break;

		case "03":
			cmes = 2;
			System.out.println("******** INI CONFIGURACION MES: *"+pMes+"********************");
			lLogger.info("******** INI CONFIGURACION MES: *"+pMes+"********************");
			for (int c1 = 0; c1 <= 11; c1++) {
				pScrren.type(Key.UP);
			}

			for (int c1 = 0; c1 < cmes; c1++) {
				pScrren.type(Key.DOWN);
			}
			System.out.println("******** FIN CONFIGURACION MES: *"+pMes+"********************");
			lLogger.info("******** FIN CONFIGURACION MES: *"+pMes+"********************");			
			break;

		case "04":
			cmes = 3;
			System.out.println("******** INI CONFIGURACION MES: *"+pMes+"********************");
			lLogger.info("******** INI CONFIGURACION MES: *"+pMes+"********************");
			for (int c1 = 0; c1 <= 11; c1++) {
				pScrren.type(Key.UP);
			}

			for (int c1 = 0; c1 < cmes; c1++) {
				pScrren.type(Key.DOWN);
			}
			System.out.println("******** FIN CONFIGURACION MES: *"+pMes+"********************");
			lLogger.info("******** FIN CONFIGURACION MES: *"+pMes+"********************");
			break;

		case "05":
			cmes = 4;
			System.out.println("******** INI CONFIGURACION MES: *"+pMes+"********************");
			lLogger.info("******** INI CONFIGURACION MES: *"+pMes+"********************");
			for (int c1 = 0; c1 <= 11; c1++) {
				pScrren.type(Key.UP);
			}

			for (int c1 = 0; c1 < cmes; c1++) {
				pScrren.type(Key.DOWN);
			}
			System.out.println("******** FIN CONFIGURACION MES: *"+pMes+"********************");
			lLogger.info("******** FIN CONFIGURACION MES: *"+pMes+"********************");			
			break;

		case "06":
			cmes = 5;
			System.out.println("******** INI CONFIGURACION MES: *"+pMes+"********************");
			lLogger.info("******** INI CONFIGURACION MES: *"+pMes+"********************");
			for (int c1 = 0; c1 <= 11; c1++) {
				pScrren.type(Key.UP);
			}

			for (int c1 = 0; c1 < cmes; c1++) {
				pScrren.type(Key.DOWN);
			}
			System.out.println("******** FIN CONFIGURACION MES: *"+pMes+"********************");
			lLogger.info("******** FIN CONFIGURACION MES: *"+pMes+"********************");			
			break;

		case "07":
			cmes = 6;
			System.out.println("******** INI CONFIGURACION MES: *"+pMes+"********************");
			lLogger.info("******** INI CONFIGURACION MES: *"+pMes+"********************");
			for (int c1 = 0; c1 <= 11; c1++) {
				pScrren.type(Key.UP);
			}

			for (int c1 = 0; c1 < cmes; c1++) {
				pScrren.type(Key.DOWN);
			}
			System.out.println("******** FIN CONFIGURACION MES: *"+pMes+"********************");
			lLogger.info("******** FIN CONFIGURACION MES: *"+pMes+"********************");			
			break;

		case "08":
			cmes = 7;
			System.out.println("******** INI CONFIGURACION MES: *"+pMes+"********************");
			lLogger.info("******** INI CONFIGURACION MES: *"+pMes+"********************");
			for (int c1 = 0; c1 <= 11; c1++) {
				pScrren.type(Key.UP);
			}

			for (int c1 = 0; c1 < cmes; c1++) {
				pScrren.type(Key.DOWN);
			}
			System.out.println("******** FIN CONFIGURACION MES: *"+pMes+"********************");
			lLogger.info("******** FIN CONFIGURACION MES: *"+pMes+"********************");
			break;

		case "09":
			cmes = 8;
			System.out.println("******** INI CONFIGURACION MES: *"+pMes+"********************");
			lLogger.info("******** INI CONFIGURACION MES: *"+pMes+"********************");
			for (int c1 = 0; c1 <= 11; c1++) {
				pScrren.type(Key.UP);
			}

			for (int c1 = 0; c1 < cmes; c1++) {
				pScrren.type(Key.DOWN);
			}
			System.out.println("******** FIN CONFIGURACION MES: *"+pMes+"********************");
			lLogger.info("******** FIN CONFIGURACION MES: *"+pMes+"********************");
			break;

		case "10":
			cmes = 9;
			System.out.println("******** INI CONFIGURACION MES: *"+pMes+"********************");
			lLogger.info("******** INI CONFIGURACION MES: *"+pMes+"********************");
			for (int c1 = 0; c1 <= 11; c1++) {
				pScrren.type(Key.UP);
			}

			for (int c1 = 0; c1 < cmes; c1++) {
				pScrren.type(Key.DOWN);
			}
			System.out.println("******** FIN CONFIGURACION MES: *"+pMes+"********************");
			lLogger.info("******** FIN CONFIGURACION MES: *"+pMes+"********************");
			break;

		case "11":
			cmes = 10;
			System.out.println("******** INI CONFIGURACION MES: *"+pMes+"********************");
			lLogger.info("******** INI CONFIGURACION MES: *"+pMes+"********************");
			for (int c1 = 0; c1 <= 11; c1++) {
				pScrren.type(Key.UP);
			}

			for (int c1 = 0; c1 < cmes; c1++) {
				pScrren.type(Key.DOWN);
			}
			System.out.println("******** FIN CONFIGURACION MES: *"+pMes+"********************");
			lLogger.info("******** FIN CONFIGURACION MES: *"+pMes+"********************");
			break;

		case "12":
			cmes = 11;
			System.out.println("******** INI CONFIGURACION MES: *"+pMes+"********************");
			lLogger.info("******** INI CONFIGURACION MES: *"+pMes+"********************");
			for (int c1 = 0; c1 <= 11; c1++) {
				pScrren.type(Key.UP);
			}

			for (int c1 = 0; c1 < cmes; c1++) {
				pScrren.type(Key.DOWN);
			}
			System.out.println("******** FIN CONFIGURACION MES: *"+pMes+"********************");
			lLogger.info("******** FIN CONFIGURACION MES: *"+pMes+"********************");
			break;

		default:
			System.out.println("******** FIN EL DIA NO SE ENCUENTRA CONFIGURADO *********************");
			lLogger.info("******** FIN EL DIA NO SE ENCUENTRA CONFIGURADO *********************");
			break;
		}
	 
		System.out.println("******** FIN MES DESCARGA *********************");
		lLogger.info("******** FIN MES DESCARGA *********************");
		
	}
	 
	public static void AsignaDia(Screen pScrren,String pDia) {
	   try {
		   
		System.out.println("******** INI SELECCION DIAS*********************");
		lLogger.info("******** INI SELECCION DIAS*********************");
		
		if (pDia.isEmpty())//(pDia.equals("TODOS")) 
		{
			
			System.out.println("******** INI CONFIGURACION DIA: *"+pDia+"********************");
			lLogger.info("******** INI CONFIGURACION DIA: *"+pDia+"********************");
			
			pScrren.type(Key.TAB);
			for (int c1 = 0; c1 <= 31; c1++) {
				pScrren.type(Key.UP);
			}
			System.out.println("******** FIN CONFIGURACION DIA: *"+pDia+"********************");
			lLogger.info("******** FIN CONFIGURACION DIA: *"+pDia+"********************");
			
		}else if (pDia.equals("TODOS")) 
		{
			System.out.println("******** INI CONFIGURACION POR DIAS: *"+pDia+"********************");
			lLogger.info("******** INI CONFIGURACION POR DIAS: *"+pDia+"********************");
			
			Thread.sleep(1000);
			pScrren.type(Key.DOWN);
			Thread.sleep(1000);
			
			System.out.println("******** FIN CONFIGURACION POR DIAS: *"+pDia+"********************");
			lLogger.info("******** FIN CONFIGURACION POR DIAS: *"+pDia+"********************");
		}
		
		System.out.println("******** FIN SELECCION DIAS*********************");
		lLogger.info("******** FIN SELECCION DIAS*********************");
		
	  }catch(Exception lError)
		{   lLogger.error(lError);
		    lError.printStackTrace();
		} catch (InterruptedException lEInterruptedException) {
			 lLogger.error(lEInterruptedException);
			 lEInterruptedException.printStackTrace();
	  } 
	}
	
	public static void AsignaTipoComprobante(Screen pScreen, String TipoComp)  {
		
		try {
			
	    System.out.println("******** INI ASIGNACION DE TIPO COMPROBANTE*********************");
		lLogger.info("******** INI ASIGNACION DE TIPO COMPROBANTE*********************");
		
	if (TipoComp.isEmpty()) {
		
		if (pScreen.exists("/btnTodosComprob.png", 10) != null) {
			pScreen.click("/btnTodosComprob.png", 10000);
			Thread.sleep(300);
			pScreen.click("/accionTodosComprobantes.png", 10000);
		}
	}
	else if (TipoComp!=null) {	
		switch (TipoComp) {
		
		case "TODOS":
			if (pScreen.exists("/btnTodosComprob.png") != null) {
				System.out.println("ENTRA AQUI****");
				pScreen.click("/btnTodosComprob.png", 10000);
				Thread.sleep(300);
				pScreen.click("/accionTodosComprobantes.png", 10000);
			}
		
		case "01":
			if (pScreen.exists("/btnTodosComprob.png") != null) {
				pScreen.click("/btnTodosComprob.png", 10000);
				Thread.sleep(300);
				pScreen.click("/accionFactura.png", 10000);
			}
			break;

		case "04":
			if (pScreen.exists("/btnTodosComprob.png") != null) {
				pScreen.click("/btnTodosComprob.png", 10000);
				Thread.sleep(300);
			    pScreen.click("/accionNotacredito.png", 10000);
			}
			break;

		case "05":
			if (pScreen.exists("/btnTodosComprob.png") != null) {
				pScreen.click("/btnTodosComprob.png", 10000);
				Thread.sleep(300);
				pScreen.click("/accionNotadebito.png", 10000);
			}
			break;
		case "07":
			if (pScreen.exists("/btnTodosComprob.png") != null) {
				pScreen.click("/btnTodosComprob.png", 10000);
				Thread.sleep(300);
				pScreen.click("/accionRetencion.png", 10000);
			}
			break;

		default:
			System.out.println("******** FIN EL TIPO DE COMPROBANTE NO SE ENCUENTRA CONFIGURADO*********************");
			lLogger.info("******** FIN EL TIPO DE COMPROBANTE NO SE ENCUENTRA CONFIGURADO*********************");
			break;
		}
	} //FIN DE SELECCION DE MES
		System.out.println("******** FIN ASIGNACION DE TIPO COMPROBANTE*********************");
		lLogger.info("******** FIN ASIGNACION DE TIPO COMPROBANTE*********************");
		
		}catch(Exception lError)
		{   lLogger.error(lError);
		    lError.printStackTrace();
		} catch (InterruptedException lEInterruptedException) {
			 lLogger.error(lEInterruptedException);
			 lEInterruptedException.printStackTrace();
	    } catch (FindFailed lEFindFailed) {
			 lLogger.error(lEFindFailed);
			 lEFindFailed.printStackTrace();
		}
		
	}
	
	public static int ValidacionDias(String pMes,String pAnio) {
		int result=0;
		 String opAnio=null; //** validando
		 String mesDescarga=null;
		 
		 System.out.println("******** INI ASIGNACION CONFIGURADO POR DIA *********************");
	     lLogger.info("******** INI ASIGNACION CONFIGURADO POR DIA *********************");
	     
		opAnio=Integer.toString(Calendar.YEAR);
 		mesDescarga= Integer.toString(Calendar.MONTH);
 		
		switch(pMes){
		
		    case "1":
		    	if (pMes == opAnio && pAnio==mesDescarga) {
		    		result=ExtraerMesesEjecucion.diaActual()-1;
		    	}else {
		    	result=31;
		    	}
		    	break;
		    
		    case "2":
		    	if (pMes == opAnio && pAnio==mesDescarga) {
		    		result=ExtraerMesesEjecucion.diaActual()-1;
		    	}else {
		    	result=28;
		    	}
		    	break;
		    	
		    case "3":
		    	if (pMes == opAnio && pAnio==mesDescarga) {
		    		result=ExtraerMesesEjecucion.diaActual()-1;
		    	}else {
		    	result=31;
		    	}
		    	break;
		    	
		    case "4":
		    	if (pMes == opAnio && pAnio==mesDescarga) {
		    		result=ExtraerMesesEjecucion.diaActual()-1;
		    	}else {
		    	result=30;
		    	}
		    	break;
		    
		    case "5":
		    	if (pMes == opAnio && pAnio==mesDescarga) {
		    		result=ExtraerMesesEjecucion.diaActual()-1;
		    	}else {
		    	result=31;
		    	}
		    	break;
		    	
		    case "6":
		    	if (pMes == opAnio && pAnio==mesDescarga) {
		    		result=ExtraerMesesEjecucion.diaActual()-1;
		    	}else {
		    	result=30;
		    	}
		    	break;
		    	
		    case "7":
		    	if (pMes == opAnio && pAnio==mesDescarga) {
		    		result=ExtraerMesesEjecucion.diaActual()-1;
		    	}else {
		    	result=31;
		    	}
		    	break;
		    
		    case "8":
		    	if (pMes == opAnio && pAnio==mesDescarga) {
		    		result=ExtraerMesesEjecucion.diaActual()-1;
		    	}else {
		    	result=31;
		    	}
		    	break;
		    
		    case "9":
		    	if (pMes == opAnio && pAnio==mesDescarga) {
		    		result=ExtraerMesesEjecucion.diaActual()-1;
		    	}else {
		    	result=30;
		    	}
		    	break;
		    
		    case "10":
		    	if (pMes == opAnio && pAnio==mesDescarga) {
		    		result=ExtraerMesesEjecucion.diaActual()-1;
		    	}else {
		    	result=31;
		    	}
		    	break;
		    	
		    case "11":
		    	if (pMes == opAnio && pAnio==mesDescarga) {
		    		result=ExtraerMesesEjecucion.diaActual()-1;
		    	}else {
		    	result=30;
		    	}
		    	break;
		    
		    case "12":
		    	if (pMes == opAnio && pAnio==mesDescarga) {
		    		result=ExtraerMesesEjecucion.diaActual()-1;
		    	}else {
		    	result=31;
		    	}
		    	break;
		
			default:
			System.out.println("******** EL TIPO DE ANIO NO SE ENCUENTRA CONFIGURADO*********************");
			lLogger.info("******** EL TIPO DE COMPROBANTE NO SE ENCUENTRA CONFIGURADO*********************");
			break;
		}
		
		 System.out.println("******** FIN ASIGNACION CONFIGURADO POR DIA *********************");
	     lLogger.info("******** FIN ASIGNACION CONFIGURADO POR DIA *********************");
		
		return result;
	}
	
}
