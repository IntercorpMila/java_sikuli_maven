package com.corlasosa.pruebas;
import java.util.Calendar;
import java.util.TreeMap;

public class ExtraerMesesEjecucion {
	

	public static TreeMap<String, Integer> extraeMesesAProcesar() {
		Calendar c1 = Calendar.getInstance();
		TreeMap<String,Integer > lListado= new TreeMap<String,Integer >();
		lListado.put(mascaraString(c1.get(Calendar.MONTH)+1), c1.get(Calendar.YEAR));
	    c1.add(Calendar.MONTH, -1);
	    lListado.put(mascaraString(c1.get(Calendar.MONTH)+1), c1.get(Calendar.YEAR));
	  //  c1.add(Calendar.MONTH, -1);
	  //  lListado.put(mascaraString(c1.get(Calendar.MONTH)+1), c1.get(Calendar.YEAR));
		return lListado;
	}
	
	public static  String mascaraString(Integer pMes) {
		String lSalida="";
	
		if(pMes>0 && pMes<10)
			lSalida="0"+pMes.toString();
		else
			lSalida=pMes.toString();
     	return lSalida;
		
	}
	
	public static  Integer diaActual() {
		Calendar c1 = Calendar.getInstance();
		return c1.get(Calendar.DATE);
	}
	
}
