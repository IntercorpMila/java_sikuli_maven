@javax.xml.bind.annotation.XmlSchema(namespace = "http://servicioweb.conector.comprobanteselectronicos.producto.com/")
package comprobanteselectronicos.conector.servicioweb;
