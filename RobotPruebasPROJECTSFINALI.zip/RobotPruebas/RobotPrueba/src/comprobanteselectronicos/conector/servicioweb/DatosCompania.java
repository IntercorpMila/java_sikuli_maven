
package comprobanteselectronicos.conector.servicioweb;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for datosCompania complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="datosCompania">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="aplicaFactura" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="aplicaNotaCredito" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="aplicaNotaDebito" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="aplicaRetencion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="claveSRI" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="identificacion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nombreEmpresa" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nombreSuscriptor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="prioridad" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="usuarioAdicional" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="lMensajeError" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mActFactura" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mActNotaCredito" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mActNotaDebito" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mActRetencion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mAntFactura" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mAntNotaCredito" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mAntNotaDebito" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mAntRetencion" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "datosCompania", propOrder = {
    "aplicaFactura",
    "aplicaNotaCredito",
    "aplicaNotaDebito",
    "aplicaRetencion",
    "claveSRI",
    "identificacion",
    "nombreEmpresa",
    "nombreSuscriptor",
    "prioridad",
    "usuarioAdicional",
    "lMensajeError",
    "mActFactura",
    "mActNotaCredito",
    "mActNotaDebito",
    "mActRetencion",
    "mAntFactura",
    "mAntNotaCredito",
    "mAntNotaDebito",
    "mAntRetencion"
})
public class DatosCompania {

    protected String aplicaFactura;
    protected String aplicaNotaCredito;
    protected String aplicaNotaDebito;
    protected String aplicaRetencion;
    protected String claveSRI;
    protected String identificacion;
    protected String nombreEmpresa;
    protected String nombreSuscriptor;
    protected String prioridad;
    protected String usuarioAdicional;
    protected String lMensajeError;
    protected String mActFactura;
    protected String mActNotaCredito;
    protected String mActNotaDebito;
    protected String mActRetencion;
    protected String mAntFactura;
    protected String mAntNotaCredito;
    protected String mAntNotaDebito;
    protected String mAntRetencion;

    /**
     * Gets the value of the aplicaFactura property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAplicaFactura() {
        return aplicaFactura;
    }

    /**
     * Sets the value of the aplicaFactura property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAplicaFactura(String value) {
        this.aplicaFactura = value;
    }

    /**
     * Gets the value of the aplicaNotaCredito property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAplicaNotaCredito() {
        return aplicaNotaCredito;
    }

    /**
     * Sets the value of the aplicaNotaCredito property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAplicaNotaCredito(String value) {
        this.aplicaNotaCredito = value;
    }

    /**
     * Gets the value of the aplicaNotaDebito property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAplicaNotaDebito() {
        return aplicaNotaDebito;
    }

    /**
     * Sets the value of the aplicaNotaDebito property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAplicaNotaDebito(String value) {
        this.aplicaNotaDebito = value;
    }

    /**
     * Gets the value of the aplicaRetencion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAplicaRetencion() {
        return aplicaRetencion;
    }

    /**
     * Sets the value of the aplicaRetencion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAplicaRetencion(String value) {
        this.aplicaRetencion = value;
    }

    /**
     * Gets the value of the claveSRI property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClaveSRI() {
        return claveSRI;
    }

    /**
     * Sets the value of the claveSRI property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClaveSRI(String value) {
        this.claveSRI = value;
    }

    /**
     * Gets the value of the identificacion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIdentificacion() {
        return identificacion;
    }

    /**
     * Sets the value of the identificacion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIdentificacion(String value) {
        this.identificacion = value;
    }

    /**
     * Gets the value of the nombreEmpresa property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNombreEmpresa() {
        return nombreEmpresa;
    }

    /**
     * Sets the value of the nombreEmpresa property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNombreEmpresa(String value) {
        this.nombreEmpresa = value;
    }

    /**
     * Gets the value of the nombreSuscriptor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNombreSuscriptor() {
        return nombreSuscriptor;
    }

    /**
     * Sets the value of the nombreSuscriptor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNombreSuscriptor(String value) {
        this.nombreSuscriptor = value;
    }

    /**
     * Gets the value of the prioridad property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPrioridad() {
        return prioridad;
    }

    /**
     * Sets the value of the prioridad property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPrioridad(String value) {
        this.prioridad = value;
    }

    /**
     * Gets the value of the usuarioAdicional property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUsuarioAdicional() {
        return usuarioAdicional;
    }

    /**
     * Sets the value of the usuarioAdicional property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUsuarioAdicional(String value) {
        this.usuarioAdicional = value;
    }

    /**
     * Gets the value of the lMensajeError property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLMensajeError() {
        return lMensajeError;
    }

    /**
     * Sets the value of the lMensajeError property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLMensajeError(String value) {
        this.lMensajeError = value;
    }

    /**
     * Gets the value of the mActFactura property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMActFactura() {
        return mActFactura;
    }

    /**
     * Sets the value of the mActFactura property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMActFactura(String value) {
        this.mActFactura = value;
    }

    /**
     * Gets the value of the mActNotaCredito property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMActNotaCredito() {
        return mActNotaCredito;
    }

    /**
     * Sets the value of the mActNotaCredito property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMActNotaCredito(String value) {
        this.mActNotaCredito = value;
    }

    /**
     * Gets the value of the mActNotaDebito property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMActNotaDebito() {
        return mActNotaDebito;
    }

    /**
     * Sets the value of the mActNotaDebito property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMActNotaDebito(String value) {
        this.mActNotaDebito = value;
    }

    /**
     * Gets the value of the mActRetencion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMActRetencion() {
        return mActRetencion;
    }

    /**
     * Sets the value of the mActRetencion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMActRetencion(String value) {
        this.mActRetencion = value;
    }

    /**
     * Gets the value of the mAntFactura property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMAntFactura() {
        return mAntFactura;
    }

    /**
     * Sets the value of the mAntFactura property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMAntFactura(String value) {
        this.mAntFactura = value;
    }

    /**
     * Gets the value of the mAntNotaCredito property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMAntNotaCredito() {
        return mAntNotaCredito;
    }

    /**
     * Sets the value of the mAntNotaCredito property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMAntNotaCredito(String value) {
        this.mAntNotaCredito = value;
    }

    /**
     * Gets the value of the mAntNotaDebito property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMAntNotaDebito() {
        return mAntNotaDebito;
    }

    /**
     * Sets the value of the mAntNotaDebito property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMAntNotaDebito(String value) {
        this.mAntNotaDebito = value;
    }

    /**
     * Gets the value of the mAntRetencion property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMAntRetencion() {
        return mAntRetencion;
    }

    /**
     * Sets the value of the mAntRetencion property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMAntRetencion(String value) {
        this.mAntRetencion = value;
    }

}
