
package comprobanteselectronicos.conector.servicioweb;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.producto.comprobanteselectronicos.conector.servicioweb package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _DatosCompania_QNAME = new QName("http://servicioweb.conector.comprobanteselectronicos.producto.com/", "datosCompania");
    private final static QName _VerificacionManualResponse_QNAME = new QName("http://servicioweb.conector.comprobanteselectronicos.producto.com/", "verificacionManualResponse");
    private final static QName _InformacionCompania_QNAME = new QName("http://servicioweb.conector.comprobanteselectronicos.producto.com/", "informacionCompania");
    private final static QName _InformacionCompaniaResponse_QNAME = new QName("http://servicioweb.conector.comprobanteselectronicos.producto.com/", "informacionCompaniaResponse");
    private final static QName _VerificacionManual_QNAME = new QName("http://servicioweb.conector.comprobanteselectronicos.producto.com/", "verificacionManual");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.producto.comprobanteselectronicos.conector.servicioweb
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link VerificacionManualResponse }
     * 
     */
    public VerificacionManualResponse createVerificacionManualResponse() {
        return new VerificacionManualResponse();
    }

    /**
     * Create an instance of {@link DatosCompania }
     * 
     */
    public DatosCompania createDatosCompania() {
        return new DatosCompania();
    }

    /**
     * Create an instance of {@link VerificacionManual }
     * 
     */
    public VerificacionManual createVerificacionManual() {
        return new VerificacionManual();
    }

    /**
     * Create an instance of {@link InformacionCompaniaResponse }
     * 
     */
    public InformacionCompaniaResponse createInformacionCompaniaResponse() {
        return new InformacionCompaniaResponse();
    }

    /**
     * Create an instance of {@link InformacionCompania }
     * 
     */
    public InformacionCompania createInformacionCompania() {
        return new InformacionCompania();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DatosCompania }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicioweb.conector.comprobanteselectronicos.producto.com/", name = "datosCompania")
    public JAXBElement<DatosCompania> createDatosCompania(DatosCompania value) {
        return new JAXBElement<DatosCompania>(_DatosCompania_QNAME, DatosCompania.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VerificacionManualResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicioweb.conector.comprobanteselectronicos.producto.com/", name = "verificacionManualResponse")
    public JAXBElement<VerificacionManualResponse> createVerificacionManualResponse(VerificacionManualResponse value) {
        return new JAXBElement<VerificacionManualResponse>(_VerificacionManualResponse_QNAME, VerificacionManualResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InformacionCompania }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicioweb.conector.comprobanteselectronicos.producto.com/", name = "informacionCompania")
    public JAXBElement<InformacionCompania> createInformacionCompania(InformacionCompania value) {
        return new JAXBElement<InformacionCompania>(_InformacionCompania_QNAME, InformacionCompania.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link InformacionCompaniaResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicioweb.conector.comprobanteselectronicos.producto.com/", name = "informacionCompaniaResponse")
    public JAXBElement<InformacionCompaniaResponse> createInformacionCompaniaResponse(InformacionCompaniaResponse value) {
        return new JAXBElement<InformacionCompaniaResponse>(_InformacionCompaniaResponse_QNAME, InformacionCompaniaResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link VerificacionManual }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://servicioweb.conector.comprobanteselectronicos.producto.com/", name = "verificacionManual")
    public JAXBElement<VerificacionManual> createVerificacionManual(VerificacionManual value) {
        return new JAXBElement<VerificacionManual>(_VerificacionManual_QNAME, VerificacionManual.class, null, value);
    }

}
