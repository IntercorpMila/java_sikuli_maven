package accesoBD;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import data.Credenciales;
import util.ServicioPropertie;

public class GestionDB {
	
	static final Logger lLogger = Logger.getLogger(GestionDB.class);
	private String lConnectionUrl;
	private String lDriverConexion;
	private Connection lConnection;
	private PreparedStatement lPreparedStatementSQL;
	private ResultSet lResultSetSQL;	
	
	public Connection getConnection() {
		
		lConnectionUrl=	ServicioPropertie.getPropiedad("url.conexion");
		lDriverConexion= ServicioPropertie.getPropiedad("driver.conexion");
    	Connection connection = null;
		try {
			Class.forName(lDriverConexion);
			connection = DriverManager.getConnection(lConnectionUrl);
		} catch (Exception e) {
			e.printStackTrace();
			lLogger.error(e);
		}
		return connection;
	}
		
// las clases deben ir con mayuscula los metodos deben ir con minuscula ojo con eso
	public void insertarLog(String pRucDestinatario, String pMensaje, String pTipo) throws Exception{
		lConnection=getConnection();
		if (lConnection != null) {
			try {
				
				String lSentenciaRegistroInserta = ServicioPropertie.getPropiedad("query.insert");
				lPreparedStatementSQL = lConnection.prepareStatement(lSentenciaRegistroInserta);
				
				lPreparedStatementSQL.setString(1, pRucDestinatario);
				lPreparedStatementSQL.setString(2, pMensaje);
				lPreparedStatementSQL.setString(3, pTipo);
				lPreparedStatementSQL.execute();
				
				lConnection.commit();
				
			} catch (SQLException lErrorSentencia) {
				
				lErrorSentencia.printStackTrace();
				lLogger.error("Error actualizarRecCorreos - SQLException: "+ lErrorSentencia.getMessage());
			    throw new Exception("Error en ejecutar sentencia: " + lErrorSentencia.getMessage()); 
			   
			} finally {
				
				if (lPreparedStatementSQL != null){
					try {
						lPreparedStatementSQL.close();
					} catch (Exception lErrorResul) {
						lLogger.error("Error InsertaLog - Exception  preparedStatementSQL: "+ lErrorResul.getMessage());
						lErrorResul.printStackTrace();
					}
				}				
				
			}
	  		try {
	  			lConnection.close();
			} catch (Exception lErrorGeneral) {
			   lErrorGeneral.printStackTrace();
			   lLogger.error("Error InsertaLog - cerrando conexion: "+ lErrorGeneral.getMessage());
			}
		}
	}
	
	public List<String> obtenerSuscriptor() {

		String resultado="";
		List<String> lSuscriptor= new ArrayList<>();
		lConnection=getConnection();
		
		if (lConnection != null) {
			try {
				String lStrQuery =  ServicioPropertie.getPropiedad("consultaSuscriptor");
				lPreparedStatementSQL = lConnection.prepareStatement(lStrQuery);
				lResultSetSQL = lPreparedStatementSQL.executeQuery();
				
				while (lResultSetSQL.next()) {
					
					resultado=lResultSetSQL.getString("id_suscriptor");
					lSuscriptor.add(resultado);
					
				}
			} catch (Exception lErrorPrincipal) {
				lLogger.error(lErrorPrincipal);
				lErrorPrincipal.printStackTrace();
				
			}
			finally {
				if (lResultSetSQL != null){
					try {
						lResultSetSQL.close();		
						lPreparedStatementSQL.close();
					} catch (Exception lErrorResul) {
						lLogger.error(lErrorResul);
						lErrorResul.printStackTrace();
					}
				}				
			}
			try {
				lConnection.close();
			} catch (Exception lError) {
				lLogger.error(lError);
				lError.printStackTrace();
				
			}
		}
		return lSuscriptor;
	}
	
	public List<String> obtenerCompaniaSuscriptor( String pSuscriptor) {

		String resultado="";
		List<String> lCompania= new ArrayList<>();
		lConnection=getConnection();
		if (lConnection != null) {
			try {
				String lStrQuery =  ServicioPropertie.getPropiedad("consultaCompania");
				lPreparedStatementSQL = lConnection.prepareStatement(lStrQuery);
				lPreparedStatementSQL.setString(1, pSuscriptor);
				lResultSetSQL = lPreparedStatementSQL.executeQuery();
				while (lResultSetSQL.next()) {
					
					resultado=lResultSetSQL.getString("identificacion");
					lCompania.add(resultado);
				
				}
			} catch (Exception lErrorPrincipal) {
				lLogger.error(lErrorPrincipal);
				lErrorPrincipal.printStackTrace();
				
			}
			finally {
				if (lResultSetSQL != null){
					try {
						lResultSetSQL.close();		
						lPreparedStatementSQL.close();
					} catch (Exception lErrorResul) {
						lLogger.error(lErrorResul);
						lErrorResul.printStackTrace();
					}
				}				
			}
			try {
				lConnection.close();
			} catch (Exception lError) {
				lLogger.error(lError);
				lError.printStackTrace();
				
			}
		}
		return lCompania;
	}
	
	public Credenciales ObtenerCredenciales(String lSuscriptor ,String lCompania) {

		lLogger.info("---- ObtenerCredenciales ----");
		//List<Credenciales> lCredenciales= new ArrayList<Credenciales>();
		lConnection=getConnection();
		
		Credenciales credenciales = new Credenciales();
		if (lConnection != null) {
			try {
				
				String lStrQuery =  ServicioPropertie.getPropiedad("query.obtener.credenciales");
				lLogger.info("Obtener Query="+lStrQuery);

				lPreparedStatementSQL = lConnection.prepareStatement(lStrQuery);
				lPreparedStatementSQL.setString(1, lSuscriptor);
		    	lPreparedStatementSQL.setString(2, lCompania);
				lResultSetSQL = lPreparedStatementSQL.executeQuery();
				
				while (lResultSetSQL.next()) {
					
					credenciales.setUsuario(lResultSetSQL.getString("USUARIO"));
					credenciales.setUsuarioAdicional(lResultSetSQL.getString("USUARIO_ADICIONAL"));
					credenciales.setClave(lResultSetSQL.getString("CLAVE"));
					//lCredenciales.add(credenciales);
				}
			} catch (Exception lErrorPrincipal) {
				lLogger.error(lErrorPrincipal);
				lErrorPrincipal.printStackTrace();
				
			}
			finally {
				if (lResultSetSQL != null){
					try {
						lResultSetSQL.close();		
						lPreparedStatementSQL.close();
					} catch (Exception lErrorResul) {
						lLogger.error(lErrorResul);
						lErrorResul.printStackTrace();
					}
				}				
			}
			try {
				lConnection.close();
			} catch (Exception lError) {
				lLogger.error(lError);
				lError.printStackTrace();
				
			}
		}
		lLogger.info("---- Fin obtenerSuscriptor ----");

		return credenciales;
	}
	
}
