package util;


import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.corlasosa.pruebas.RobotPruebas;

public class ServicioPropertie {
	
	private static final Properties prop;
	private static String filePath;
	
	static {
		 prop = new Properties();
		 InputStream entrada = null;
		 try {
			System.out.println("entrada::"+RobotPruebas.lDirProperties);
			entrada = new FileInputStream(RobotPruebas.lDirProperties);
			System.out.println("entrada::"+RobotPruebas.lDirProperties);
			prop.load(entrada);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static String getPropiedad(String clave){
		return prop.getProperty(clave);
	}
	
	public void setEntrada (String pfilePath) {
		System.out.println("entrada::*********"+pfilePath);
		this.filePath=pfilePath;
		 System.out.println("entrada::*********"+this.filePath);
	}

}
